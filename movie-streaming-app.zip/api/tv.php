<?php
include 'api-key.php';
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', 0);

$page = $_GET['page'] ?? 1;

// Get popular TV shows from TMDb
$url = 'https://api.themoviedb.org/3/tv/popular?api_key='.$apikey.'&page='.$page;
$json_string = file_get_contents($url);
$parsed_json = json_decode($json_string, true);

// Add embed URLs to each result
if (isset($parsed_json['results']) && is_array($parsed_json['results'])) {
    foreach ($parsed_json['results'] as &$show) {
        if (isset($show['id'])) {
            $show['embed_url'] = 'https://vidsrc.me/embed/tv?tmdb='.$show['id'];
        }
    }
}

echo json_encode($parsed_json);
?>
