<?php
$apikey = 'ae4bd1b6fce2a5648671bfc171d15ba4';
?>
