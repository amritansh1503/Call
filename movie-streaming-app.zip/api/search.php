<?php
include 'api-key.php';
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', 0);

$query = $_GET['q'] ?? '';
$page = $_GET['page'] ?? 1;

if (empty($query)) {
    http_response_code(400);
    echo json_encode(['error' => 'Search query is required']);
    exit;
}

$search_url = 'https://api.themoviedb.org/3/search/movie?api_key='.$apikey.'&query='.urlencode($query).'&page='.$page;
$json_string = file_get_contents($search_url);
$search_results = json_decode($json_string, true);

// Add embed URLs to each result
if (isset($search_results['results']) && is_array($search_results['results'])) {
    foreach ($search_results['results'] as &$movie) {
        if (isset($movie['id'])) {
            $movie['embed_url'] = 'https://vidsrc.me/embed/movie?tmdb='.$movie['id'];
        }
    }
}

echo json_encode($search_results);
?>
