<?php
include 'api-key.php';
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', 0);

$show_id = $_GET['show_id'] ?? '';
$season_number = $_GET['season'] ?? '';

if (empty($show_id) || empty($season_number)) {
    http_response_code(400);
    echo json_encode(['error' => 'Show ID and season number are required']);
    exit;
}

// Get season details from TMDb
$url = 'https://api.themoviedb.org/3/tv/'.$show_id.'/season/'.$season_number.'?api_key='.$apikey;
$json_string = file_get_contents($url);
$season_data = json_decode($json_string, true);

if (!$season_data || isset($season_data['success']) && $season_data['success'] === false) {
    http_response_code(404);
    echo json_encode(['error' => 'Season not found']);
    exit;
}

// Add embed URLs to each episode
if (isset($season_data['episodes']) && is_array($season_data['episodes'])) {
    foreach ($season_data['episodes'] as &$episode) {
        if (isset($episode['episode_number'])) {
            $episode['embed_url'] = 'https://vidsrc.me/embed/tv?tmdb='.$show_id.'&season='.$season_number.'&episode='.$episode['episode_number'];
        }
    }
}

echo json_encode($season_data);
?>
