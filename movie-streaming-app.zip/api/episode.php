<?php
include 'api-key.php';
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', 0);

$show_id = $_GET['show_id'] ?? '';
$season = $_GET['season'] ?? '';
$episode = $_GET['episode'] ?? '';

if (empty($show_id) || empty($season) || empty($episode)) {
    http_response_code(400);
    echo json_encode(['error' => 'Show ID, season, and episode are required']);
    exit;
}

// Get episode details from TMDb
$url = 'https://api.themoviedb.org/3/tv/'.$show_id.'/season/'.$season.'/episode/'.$episode.'?api_key='.$apikey;
$json_string = file_get_contents($url);
$episode_data = json_decode($json_string, true);

if (!$episode_data || isset($episode_data['success']) && $episode_data['success'] === false) {
    http_response_code(404);
    echo json_encode(['error' => 'Episode not found']);
    exit;
}

// Add embed URL for the specific episode
$episode_data['embed_url'] = 'https://vidsrc.me/embed/tv?tmdb='.$show_id.'&season='.$season.'&episode='.$episode;

echo json_encode($episode_data);
?>
