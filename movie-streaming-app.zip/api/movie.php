<?php
include 'api-key.php';
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', 0);

$id = $_GET['id'] ?? '';

if (empty($id)) {
    http_response_code(400);
    echo json_encode(['error' => 'Movie ID is required']);
    exit;
}

// Check if it's an IMDb ID or TMDb ID
if (strpos($id, 'tt') === 0) {
    // IMDb ID
    $imdb_id = $id;
    $json = file_get_contents('http://api.themoviedb.org/3/find/'.$imdb_id.'?external_source=imdb_id&api_key='.$apikey);
    $tmdb_data = json_decode($json, true);
    
    if (isset($tmdb_data['movie_results'][0])) {
        $tmdb_id = $tmdb_data['movie_results'][0]['id'];
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'Movie not found']);
        exit;
    }
} else {
    // TMDb ID
    $tmdb_id = $id;
}

// Get detailed movie info
$json = file_get_contents('http://api.themoviedb.org/3/movie/'.$tmdb_id.'?api_key='.$apikey.'&append_to_response=credits,videos');
$movie_data = json_decode($json, true);

if (!$movie_data || isset($movie_data['success']) && $movie_data['success'] === false) {
    http_response_code(404);
    echo json_encode(['error' => 'Movie not found']);
    exit;
}

// Get embed URL from vidsrc.me
$swlink = 'https://vidsrc.me/embed/movie?tmdb='.$tmdb_id;
$movie_data['embed_url'] = $swlink;

echo json_encode($movie_data);
?>
