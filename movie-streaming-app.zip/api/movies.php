<?php
include 'api-key.php';
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', 0);

$page = $_GET['page'] ?? 1;

$swlink = 'https://vidsrc.me/movies/latest/page-'.$page.'.json';
$json_string = file_get_contents($swlink);
$parsed_json = json_decode($json_string, true);
$parsed = $parsed_json['result'];

$results = [];

foreach($parsed as $key => $value) {
    $imdb = $value['imdb_id'];
    $tmdb = $value['tmdb_id'];
    $title = $value['title'];
    $imdbembed = $value['embed_url'];
    $tmdbembed = $value['embed_url_tmdb'];
    
    $json = file_get_contents('http://api.themoviedb.org/3/find/'.$imdb.'?external_source=imdb_id&api_key='.$apikey);
    $tmdb_data = json_decode($json, true);
    
    if (isset($tmdb_data['movie_results'][0])) {
        $movie = $tmdb_data['movie_results'][0];
        $movie['imdb_id'] = $imdb;
        $movie['embed_url'] = $imdbembed;
        $movie['embed_url_tmdb'] = $tmdbembed;
        $results[] = $movie;
    }
}

echo json_encode([
    'page' => (int)$page,
    'results' => $results,
    'total_results' => count($results),
    'total_pages' => 100 // Placeholder value
]);
?>
