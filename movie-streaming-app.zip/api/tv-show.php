<?php
include 'api-key.php';
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', 0);

$id = $_GET['id'] ?? '';

if (empty($id)) {
    http_response_code(400);
    echo json_encode(['error' => 'TV Show ID is required']);
    exit;
}

// Get detailed TV show info
$json = file_get_contents('http://api.themoviedb.org/3/tv/'.$id.'?api_key='.$apikey.'&append_to_response=credits,videos');
$show_data = json_decode($json, true);

if (!$show_data || isset($show_data['success']) && $show_data['success'] === false) {
    http_response_code(404);
    echo json_encode(['error' => 'TV Show not found']);
    exit;
}

// Get embed URL from vidsrc.me
$show_data['embed_url'] = 'https://vidsrc.me/embed/tv?tmdb='.$id;

echo json_encode($show_data);
?>
