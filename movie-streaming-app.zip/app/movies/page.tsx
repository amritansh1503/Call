import { getMovies } from "@/lib/api"
import MovieCard from "@/components/movie-card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Suspense } from "react"
import { MovieSkeleton } from "@/components/movie-skeleton"

async function MoviesContent({ page }: { page: number }) {
  const movies = await getMovies(page)

  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4 md:gap-6 mb-8">
        {movies.map((movie) => (
          <MovieCard key={movie.id} movie={movie} />
        ))}
      </div>

      <div className="flex justify-center gap-4">
        {page > 1 && (
          <Link href={`/movies?page=${page - 1}`}>
            <Button variant="outline" className="border-gray-600 text-white hover:bg-white/10">
              Previous
            </Button>
          </Link>
        )}
        <span className="flex items-center px-4 py-2 text-gray-400">Page {page}</span>
        <Link href={`/movies?page=${page + 1}`}>
          <Button variant="outline" className="border-gray-600 text-white hover:bg-white/10">
            Next
          </Button>
        </Link>
      </div>
    </>
  )
}

function MoviesSkeleton() {
  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4 md:gap-6 mb-8">
        {Array.from({ length: 12 }).map((_, i) => (
          <MovieSkeleton key={i} />
        ))}
      </div>
      <div className="flex justify-center gap-4">
        <div className="h-10 w-20 bg-gray-800 rounded animate-pulse"></div>
        <div className="h-10 w-16 bg-gray-800 rounded animate-pulse"></div>
        <div className="h-10 w-20 bg-gray-800 rounded animate-pulse"></div>
      </div>
    </>
  )
}

export default function MoviesPage({
  searchParams,
}: {
  searchParams: { page?: string }
}) {
  const page = searchParams.page ? Number.parseInt(searchParams.page) : 1

  return (
    <main className="min-h-screen bg-black text-white pt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold mb-8 text-center">
            <span className="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">Movies</span>
          </h1>

          <Suspense key={page} fallback={<MoviesSkeleton />}>
            <MoviesContent page={page} />
          </Suspense>
        </div>
      </div>
    </main>
  )
}
