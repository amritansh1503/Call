import { getMovies } from "@/lib/api"
import { getTVShows } from "@/lib/api-tv"
import MovieCard from "@/components/movie-card"
import TVShowCard from "@/components/tv-show-card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default async function TrendingPage() {
  const [movies, tvShows] = await Promise.all([getMovies(1), getTVShows(1)])

  return (
    <main className="min-h-screen bg-black text-white pt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold mb-8 text-center">
            <span className="text-2xl mr-2">🔥</span>
            <span className="bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">
              Trending Now
            </span>
            <span className="text-2xl ml-2">🔥</span>
          </h1>

          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-gray-900 mb-8">
              <TabsTrigger value="all" className="data-[state=active]:bg-teal-600">
                All
              </TabsTrigger>
              <TabsTrigger value="movies" className="data-[state=active]:bg-teal-600">
                Movies
              </TabsTrigger>
              <TabsTrigger value="tv" className="data-[state=active]:bg-teal-600">
                TV Shows
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all">
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4 md:gap-6">
                {[...movies.slice(0, 6), ...tvShows.slice(0, 6)]
                  .sort(() => Math.random() - 0.5)
                  .map((item) =>
                    "title" in item ? (
                      <MovieCard key={`movie-${item.id}`} movie={item} />
                    ) : (
                      <TVShowCard key={`tv-${item.id}`} show={item} />
                    ),
                  )}
              </div>
            </TabsContent>

            <TabsContent value="movies">
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4 md:gap-6">
                {movies.map((movie) => (
                  <MovieCard key={movie.id} movie={movie} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="tv">
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4 md:gap-6">
                {tvShows.map((show) => (
                  <TVShowCard key={show.id} show={show} />
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </main>
  )
}
