"use client"

import { useState } from "react"
import { Star, Clock, Calendar, ThumbsUp, ThumbsDown, Share, Download } from "lucide-react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { VideoPlayer } from "@/components/video-player"
import type { MovieDetails } from "@/lib/types"
import { WatchlistButton } from "@/components/watchlist-button"
import { RatingSystem } from "@/components/rating-system"

interface MoviePageClientProps {
  movie: MovieDetails
}

export default function MoviePageClient({ movie }: MoviePageClientProps) {
  const [showPlayer, setShowPlayer] = useState(false)
  const [likes, setLikes] = useState(0)
  const [dislikes, setDislikes] = useState(0)
  const [userVote, setUserVote] = useState<"like" | "dislike" | null>(null)

  const handleVote = (type: "like" | "dislike") => {
    if (userVote === type) {
      // Remove vote
      if (type === "like") setLikes((prev) => prev - 1)
      else setDislikes((prev) => prev - 1)
      setUserVote(null)
    } else {
      // Add new vote, remove old if exists
      if (userVote === "like") setLikes((prev) => prev - 1)
      if (userVote === "dislike") setDislikes((prev) => prev - 1)

      if (type === "like") setLikes((prev) => prev + 1)
      else setDislikes((prev) => prev + 1)
      setUserVote(type)
    }
  }

  return (
    <main className="min-h-screen bg-black text-white pt-16">
      {/* Video Player Section */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Main Video Player */}
          <div className="relative mb-8">
            <div className="aspect-video bg-gray-900 rounded-lg overflow-hidden relative group">
              {movie.backdrop_path ? (
                <Image
                  src={`https://image.tmdb.org/t/p/original${movie.backdrop_path}`}
                  alt={movie.title}
                  fill
                  className="object-cover"
                  priority
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-gray-800 to-gray-900" />
              )}

              {/* Play Button Overlay */}
              <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                <Button
                  onClick={() => setShowPlayer(true)}
                  size="lg"
                  className="bg-teal-500 hover:bg-teal-600 text-white rounded-full w-20 h-20 p-0"
                >
                  <svg className="w-8 h-8 ml-1" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z" />
                  </svg>
                </Button>
              </div>

              {/* Video Controls Overlay (Static for demo) */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="flex items-center justify-between text-white">
                  <div className="flex items-center space-x-4">
                    <Button size="sm" variant="ghost" className="text-white hover:bg-white/20">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M8 5v14l11-7z" />
                      </svg>
                    </Button>
                    <span className="text-sm">
                      0:00 /{" "}
                      {movie.runtime
                        ? `${Math.floor(movie.runtime / 60)}:${(movie.runtime % 60).toString().padStart(2, "0")}`
                        : "1:41:58"}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button size="sm" variant="ghost" className="text-white hover:bg-white/20">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z" />
                      </svg>
                    </Button>
                    <Button size="sm" variant="ghost" className="text-white hover:bg-white/20">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z" />
                      </svg>
                    </Button>
                    <Button size="sm" variant="ghost" className="text-white hover:bg-white/20">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z" />
                      </svg>
                    </Button>
                  </div>
                </div>
                <div className="w-full bg-gray-600 rounded-full h-1 mt-2">
                  <div className="bg-teal-500 h-1 rounded-full" style={{ width: "15%" }}></div>
                </div>
              </div>
            </div>
          </div>

          {/* Movie Information */}
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Movie Poster */}
            <div className="lg:w-64 flex-shrink-0">
              <div className="aspect-[2/3] relative rounded-lg overflow-hidden">
                <Image
                  src={
                    movie.poster_path
                      ? `https://image.tmdb.org/t/p/w500${movie.poster_path}`
                      : "/placeholder.svg?height=450&width=300"
                  }
                  alt={movie.title}
                  fill
                  className="object-cover"
                />
              </div>
            </div>

            {/* Movie Details */}
            <div className="flex-1">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">{movie.title}</h1>

              <div className="flex flex-wrap items-center gap-4 mb-6 text-gray-400">
                {movie.runtime > 0 && (
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>{movie.runtime} min</span>
                  </div>
                )}

                {movie.release_date && (
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    <span>{new Date(movie.release_date).getFullYear()}</span>
                  </div>
                )}

                <span>Published on, 1 week ago</span>
              </div>

              {/* Rating Badge */}
              {movie.vote_average > 0 && (
                <div className="flex items-center mb-6">
                  <div className="bg-yellow-500 text-black px-3 py-1 rounded-full flex items-center">
                    <Star className="h-4 w-4 mr-1" fill="currentColor" />
                    <span className="font-bold">{Math.round(movie.vote_average * 10)}</span>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-4 mb-8">
                <Button
                  onClick={() => handleVote("like")}
                  variant={userVote === "like" ? "default" : "outline"}
                  size="sm"
                  className="flex items-center space-x-2"
                >
                  <ThumbsUp className="h-4 w-4" />
                  <span>{likes}</span>
                </Button>

                <Button
                  onClick={() => handleVote("dislike")}
                  variant={userVote === "dislike" ? "default" : "outline"}
                  size="sm"
                  className="flex items-center space-x-2"
                >
                  <ThumbsDown className="h-4 w-4" />
                  <span>{dislikes}</span>
                </Button>

                <WatchlistButton movieId={movie.id} title={movie.title} size="sm" />

                <Button variant="outline" size="sm">
                  <Share className="h-4 w-4 mr-2" />
                  Share
                </Button>

                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </Button>
              </div>

              {/* Movie Description */}
              <div className="mb-8">
                <h2 className="text-xl font-semibold mb-3">Overview</h2>
                <p className="text-gray-300 leading-relaxed">{movie.overview}</p>
              </div>

              {/* Genres */}
              {movie.genres && movie.genres.length > 0 && (
                <div className="mb-8">
                  <h3 className="text-lg font-semibold mb-3">Genres</h3>
                  <div className="flex flex-wrap gap-2">
                    {movie.genres.map((genre) => (
                      <span key={genre.id} className="bg-gray-800 text-gray-300 px-3 py-1 rounded-full text-sm">
                        {genre.name}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* User Rating */}
              <RatingSystem movieId={movie.id} title={movie.title} />
            </div>
          </div>

          {/* Cast Section */}
          {movie.credits && movie.credits.cast && movie.credits.cast.length > 0 && (
            <div className="mt-12">
              <h2 className="text-2xl font-bold mb-6">Cast</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {movie.credits.cast.slice(0, 12).map((person) => (
                  <div key={person.id} className="text-center">
                    <div className="aspect-[2/3] relative rounded-lg overflow-hidden bg-gray-800 mb-3">
                      {person.profile_path ? (
                        <Image
                          src={`https://image.tmdb.org/t/p/w200${person.profile_path}`}
                          alt={person.name}
                          fill
                          className="object-cover"
                        />
                      ) : (
                        <div className="absolute inset-0 flex items-center justify-center text-gray-500">No Image</div>
                      )}
                    </div>
                    <p className="font-medium text-sm truncate">{person.name}</p>
                    <p className="text-xs text-gray-400 truncate">{person.character}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Trailer Section */}
          {movie.videos && movie.videos.results && movie.videos.results.length > 0 && (
            <div className="mt-12">
              <h2 className="text-2xl font-bold mb-6">Trailer</h2>
              <div className="aspect-video rounded-lg overflow-hidden bg-gray-900">
                <iframe
                  src={`https://www.youtube.com/embed/${movie.videos.results[0].key}`}
                  title={movie.videos.results[0].name}
                  allowFullScreen
                  className="w-full h-full"
                ></iframe>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Video Player Modal */}
      {showPlayer && (
        <VideoPlayer
          title={movie.title}
          embedUrl={`https://vidsrc.me/embed/movie?tmdb=${movie.id}`}
          onClose={() => setShowPlayer(false)}
          movieId={movie.id}
        />
      )}
    </main>
  )
}
