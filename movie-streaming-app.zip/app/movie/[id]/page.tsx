import { getMovieDetails } from "@/lib/api"
import { notFound } from "next/navigation"
import MoviePageClient from "./movie-page-client"

export default async function MoviePage({ params }: { params: { id: string } }) {
  const movie = await getMovieDetails(params.id)

  if (!movie) {
    notFound()
  }

  return <MoviePageClient movie={movie} />
}
