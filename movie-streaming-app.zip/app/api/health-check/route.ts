import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Check TMDb API
    const API_KEY = process.env.TMDB_API_KEY || "ae4bd1b6fce2a5648671bfc171d15ba4"
    const response = await fetch(`https://api.themoviedb.org/3/configuration?api_key=${API_KEY}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
      cache: "no-store",
    })

    if (!response.ok) {
      return NextResponse.json({
        status: "offline",
        message: `TMDb API is unavailable (${response.status})`,
      })
    }

    // Check PHP API if configured
    if (process.env.PHP_API_URL) {
      try {
        const phpResponse = await fetch(`${process.env.PHP_API_URL}/health`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
          cache: "no-store",
        })

        if (!phpResponse.ok) {
          return NextResponse.json({
            status: "degraded",
            message: "PHP API is unavailable, using fallback services",
          })
        }
      } catch (error) {
        return NextResponse.json({
          status: "degraded",
          message: "PHP API is unreachable, using fallback services",
        })
      }
    }

    return NextResponse.json({ status: "online", message: "All systems operational" })
  } catch (error) {
    console.error("Health check error:", error)
    return NextResponse.json(
      {
        status: "offline",
        message: "API services are unreachable",
      },
      { status: 503 },
    )
  }
}
