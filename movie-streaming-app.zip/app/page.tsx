import MovieGrid from "@/components/movie-grid"
import { SearchBar } from "@/components/search-bar"
import { HeroSection } from "@/components/hero-section"
import { TrendingSection } from "@/components/trending-section"
import { Suspense } from "react"
import { ApiStatus } from "@/components/api-status"
import { HeroSkeleton } from "@/components/hero-skeleton"
import { TrendingSkeleton } from "@/components/trending-skeleton"
import { MovieSkeletonGrid } from "@/components/movie-skeleton-grid"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-gray-900 via-black to-black text-white">
      {/* Hero Section */}
      <Suspense fallback={<HeroSkeleton />}>
        <HeroSection />
      </Suspense>

      <div className="container mx-auto px-4 py-8">
        <ApiStatus />
        <SearchBar />

        {/* Trending Section */}
        <Suspense fallback={<TrendingSkeleton />}>
          <TrendingSection />
        </Suspense>

        {/* Latest Movies */}
        <h2 className="text-2xl font-bold mt-12 mb-6 flex items-center">
          <span className="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
            Latest Movies
          </span>
        </h2>
        <Suspense fallback={<MovieSkeletonGrid />}>
          <MovieGrid page={1} />
        </Suspense>
      </div>
    </main>
  )
}
