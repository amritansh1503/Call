import { getTVShows } from "@/lib/api-tv"
import { Suspense } from "react"
import TVShowCard from "@/components/tv-show-card"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { MovieSkeleton } from "@/components/movie-skeleton"

async function TVShowsContent({ page }: { page: number }) {
  const shows = await getTVShows(page)

  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6 mb-8">
        {shows.map((show) => (
          <TVShowCard key={show.id} show={show} />
        ))}
      </div>

      <div className="flex justify-center gap-4">
        {page > 1 && (
          <Link href={`/tv?page=${page - 1}`}>
            <Button variant="outline" className="border-gray-600 text-white hover:bg-white/10">
              Previous
            </Button>
          </Link>
        )}
        <span className="flex items-center px-4 py-2 text-gray-400">Page {page}</span>
        <Link href={`/tv?page=${page + 1}`}>
          <Button variant="outline" className="border-gray-600 text-white hover:bg-white/10">
            Next
          </Button>
        </Link>
      </div>
    </>
  )
}

function TVShowsSkeleton() {
  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6 mb-8">
        {Array.from({ length: 10 }).map((_, i) => (
          <MovieSkeleton key={i} />
        ))}
      </div>
      <div className="flex justify-center gap-4">
        <div className="h-10 w-20 bg-gray-800 rounded animate-pulse"></div>
        <div className="h-10 w-16 bg-gray-800 rounded animate-pulse"></div>
        <div className="h-10 w-20 bg-gray-800 rounded animate-pulse"></div>
      </div>
    </>
  )
}

export default async function TVShowsPage({
  searchParams,
}: {
  searchParams: { page?: string }
}) {
  const page = searchParams.page ? Number.parseInt(searchParams.page) : 1

  return (
    <main className="min-h-screen bg-black text-white pt-16">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
          TV Shows
        </h1>

        <Suspense key={page} fallback={<TVShowsSkeleton />}>
          <TVShowsContent page={page} />
        </Suspense>
      </div>
    </main>
  )
}
