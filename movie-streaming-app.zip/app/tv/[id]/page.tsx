import { getTVShowDetails } from "@/lib/api-tv"
import { notFound } from "next/navigation"
import TVShowPageClient from "./tv-show-page-client"

export default async function TVShowPage({ params }: { params: { id: string } }) {
  const show = await getTVShowDetails(params.id)

  if (!show) {
    notFound()
  }

  return <TVShowPageClient show={show} />
}
