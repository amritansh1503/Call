"use client"

import { useState } from "react"
import { Star, Clock, Calendar, ThumbsUp, ThumbsDown, Share, Download, Play } from "lucide-react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { VideoPlayer } from "@/components/video-player"
import type { TVShowDetails } from "@/lib/types"
import { WatchlistButton } from "@/components/watchlist-button"
import { RatingSystem } from "@/components/rating-system"

interface TVShowPageClientProps {
  show: TVShowDetails
}

export default function TVShowPageClient({ show }: TVShowPageClientProps) {
  const [showPlayer, setShowPlayer] = useState(false)
  const [likes, setLikes] = useState(0)
  const [dislikes, setDislikes] = useState(0)
  const [userVote, setUserVote] = useState<"like" | "dislike" | null>(null)

  const handleVote = (type: "like" | "dislike") => {
    if (userVote === type) {
      if (type === "like") setLikes((prev) => prev - 1)
      else setDislikes((prev) => prev - 1)
      setUserVote(null)
    } else {
      if (userVote === "like") setLikes((prev) => prev - 1)
      if (userVote === "dislike") setDislikes((prev) => prev - 1)

      if (type === "like") setLikes((prev) => prev + 1)
      else setDislikes((prev) => prev + 1)
      setUserVote(type)
    }
  }

  return (
    <main className="min-h-screen bg-black text-white pt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Main Video Player */}
          <div className="relative mb-8">
            <div className="aspect-video bg-gray-900 rounded-lg overflow-hidden relative group">
              {show.backdrop_path ? (
                <Image
                  src={`https://image.tmdb.org/t/p/original${show.backdrop_path}`}
                  alt={show.name}
                  fill
                  className="object-cover"
                  priority
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-gray-800 to-gray-900" />
              )}

              <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                <Button
                  onClick={() => setShowPlayer(true)}
                  size="lg"
                  className="bg-teal-500 hover:bg-teal-600 text-white rounded-full w-20 h-20 p-0"
                >
                  <Play className="w-8 h-8 ml-1" fill="currentColor" />
                </Button>
              </div>
            </div>
          </div>

          {/* Show Information */}
          <div className="flex flex-col lg:flex-row gap-8">
            <div className="lg:w-64 flex-shrink-0">
              <div className="aspect-[2/3] relative rounded-lg overflow-hidden">
                <Image
                  src={
                    show.poster_path
                      ? `https://image.tmdb.org/t/p/w500${show.poster_path}`
                      : "/placeholder.svg?height=450&width=300"
                  }
                  alt={show.name}
                  fill
                  className="object-cover"
                />
              </div>
            </div>

            <div className="flex-1">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">{show.name}</h1>

              <div className="flex flex-wrap items-center gap-4 mb-6 text-gray-400">
                {show.episode_run_time && show.episode_run_time.length > 0 && (
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>~{show.episode_run_time[0]} min per episode</span>
                  </div>
                )}

                {show.first_air_date && (
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    <span>{new Date(show.first_air_date).getFullYear()}</span>
                  </div>
                )}

                <span>
                  {show.number_of_seasons} Season{show.number_of_seasons !== 1 ? "s" : ""}
                </span>
                <span>{show.number_of_episodes} Episodes</span>
              </div>

              {show.vote_average > 0 && (
                <div className="flex items-center mb-6">
                  <div className="bg-yellow-500 text-black px-3 py-1 rounded-full flex items-center">
                    <Star className="h-4 w-4 mr-1" fill="currentColor" />
                    <span className="font-bold">{Math.round(show.vote_average * 10)}</span>
                  </div>
                </div>
              )}

              <div className="flex flex-wrap items-center gap-4 mb-8">
                <Button
                  onClick={() => handleVote("like")}
                  variant={userVote === "like" ? "default" : "outline"}
                  size="sm"
                >
                  <ThumbsUp className="h-4 w-4 mr-2" />
                  {likes}
                </Button>

                <Button
                  onClick={() => handleVote("dislike")}
                  variant={userVote === "dislike" ? "default" : "outline"}
                  size="sm"
                >
                  <ThumbsDown className="h-4 w-4 mr-2" />
                  {dislikes}
                </Button>

                <WatchlistButton showId={show.id} title={show.name} size="sm" />

                <Button variant="outline" size="sm">
                  <Share className="h-4 w-4 mr-2" />
                  Share
                </Button>

                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </Button>
              </div>

              <div className="mb-8">
                <h2 className="text-xl font-semibold mb-3">Overview</h2>
                <p className="text-gray-300 leading-relaxed">{show.overview}</p>
              </div>

              {show.genres && show.genres.length > 0 && (
                <div className="mb-8">
                  <h3 className="text-lg font-semibold mb-3">Genres</h3>
                  <div className="flex flex-wrap gap-2">
                    {show.genres.map((genre) => (
                      <span key={genre.id} className="bg-gray-800 text-gray-300 px-3 py-1 rounded-full text-sm">
                        {genre.name}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <RatingSystem showId={show.id} title={show.name} />
            </div>
          </div>

          {/* Seasons */}
          {show.seasons && show.seasons.length > 0 && (
            <div className="mt-12">
              <h2 className="text-2xl font-bold mb-6">Seasons</h2>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {show.seasons.map((season) => (
                  <Link
                    key={season.id}
                    href={`/tv/${show.id}/season/${season.season_number}`}
                    className="bg-gray-900 rounded-lg overflow-hidden border border-gray-800 hover:border-teal-500 transition-colors group"
                  >
                    <div className="flex">
                      <div className="w-1/3">
                        {season.poster_path ? (
                          <Image
                            src={`https://image.tmdb.org/t/p/w200${season.poster_path}`}
                            alt={season.name}
                            width={200}
                            height={300}
                            className="h-full object-cover"
                          />
                        ) : (
                          <div className="h-full bg-gray-800 flex items-center justify-center">
                            <span className="text-gray-500">No Image</span>
                          </div>
                        )}
                      </div>
                      <div className="w-2/3 p-4">
                        <h3 className="font-semibold text-lg mb-2 group-hover:text-teal-400 transition-colors">
                          {season.name}
                        </h3>
                        <p className="text-sm text-gray-400 mb-2">{season.episode_count} episodes</p>
                        {season.air_date && (
                          <p className="text-sm text-gray-400 mb-2">{new Date(season.air_date).getFullYear()}</p>
                        )}
                        {season.overview && <p className="text-sm text-gray-300 line-clamp-3">{season.overview}</p>}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {/* Cast */}
          {show.credits && show.credits.cast && show.credits.cast.length > 0 && (
            <div className="mt-12">
              <h2 className="text-2xl font-bold mb-6">Cast</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {show.credits.cast.slice(0, 12).map((person) => (
                  <div key={person.id} className="text-center">
                    <div className="aspect-[2/3] relative rounded-lg overflow-hidden bg-gray-800 mb-3">
                      {person.profile_path ? (
                        <Image
                          src={`https://image.tmdb.org/t/p/w200${person.profile_path}`}
                          alt={person.name}
                          fill
                          className="object-cover"
                        />
                      ) : (
                        <div className="absolute inset-0 flex items-center justify-center text-gray-500">No Image</div>
                      )}
                    </div>
                    <p className="font-medium text-sm truncate">{person.name}</p>
                    <p className="text-xs text-gray-400 truncate">{person.character}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {showPlayer && (
        <VideoPlayer
          title={show.name}
          embedUrl={`https://vidsrc.me/embed/tv?tmdb=${show.id}`}
          onClose={() => setShowPlayer(false)}
          showId={show.id}
        />
      )}
    </main>
  )
}
