"use client"

import { useState, useEffect } from "react"
import { getSeasonDetails } from "@/lib/api-tv"
import { EpisodePlayer } from "@/components/episode-player"
import { Button } from "@/components/ui/button"
import { Play, Calendar, Clock } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"

interface Episode {
  id: number
  name: string
  overview: string
  episode_number: number
  air_date: string
  runtime: number
  still_path: string | null
  vote_average: number
}

interface SeasonDetails {
  id: number
  name: string
  overview: string
  poster_path: string | null
  season_number: number
  episodes: Episode[]
  air_date: string
}

export default function SeasonPage({
  params,
}: {
  params: { id: string; season: string }
}) {
  const [seasonData, setSeasonData] = useState<SeasonDetails | null>(null)
  const [showTitle, setShowTitle] = useState("")
  const [currentEpisode, setCurrentEpisode] = useState<Episode | null>(null)
  const [showPlayer, setShowPlayer] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchData() {
      try {
        const season = await getSeasonDetails(params.id, params.season)
        if (!season) {
          notFound()
        }
        setSeasonData(season)
        setShowTitle(season.show_name || "TV Show")
      } catch (error) {
        console.error("Error fetching season:", error)
        notFound()
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [params.id, params.season])

  const handleWatchEpisode = (episode: Episode) => {
    setCurrentEpisode(episode)
    setShowPlayer(true)
  }

  const handleNextEpisode = () => {
    if (!currentEpisode || !seasonData) return

    const currentIndex = seasonData.episodes.findIndex((ep) => ep.id === currentEpisode.id)
    if (currentIndex < seasonData.episodes.length - 1) {
      setCurrentEpisode(seasonData.episodes[currentIndex + 1])
    }
  }

  const handlePreviousEpisode = () => {
    if (!currentEpisode || !seasonData) return

    const currentIndex = seasonData.episodes.findIndex((ep) => ep.id === currentEpisode.id)
    if (currentIndex > 0) {
      setCurrentEpisode(seasonData.episodes[currentIndex - 1])
    }
  }

  const hasNextEpisode = () => {
    if (!currentEpisode || !seasonData) return false
    const currentIndex = seasonData.episodes.findIndex((ep) => ep.id === currentEpisode.id)
    return currentIndex < seasonData.episodes.length - 1
  }

  const hasPreviousEpisode = () => {
    if (!currentEpisode || !seasonData) return false
    const currentIndex = seasonData.episodes.findIndex((ep) => ep.id === currentEpisode.id)
    return currentIndex > 0
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500"></div>
      </div>
    )
  }

  if (!seasonData) {
    notFound()
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="mb-6">
          <Link href={`/tv/${params.id}`} className="text-purple-400 hover:text-purple-300">
            ← Back to {showTitle}
          </Link>
        </div>

        {/* Season Header */}
        <div className="flex flex-col md:flex-row gap-8 mb-8">
          <div className="w-full md:w-1/4 flex-shrink-0">
            {seasonData.poster_path ? (
              <Image
                src={`https://image.tmdb.org/t/p/w500${seasonData.poster_path}`}
                alt={seasonData.name}
                width={300}
                height={450}
                className="rounded-lg w-full"
              />
            ) : (
              <div className="bg-gray-800 rounded-lg aspect-[2/3] flex items-center justify-center">
                <span className="text-gray-500">No Image</span>
              </div>
            )}
          </div>

          <div className="flex-1">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">{seasonData.name}</h1>
            <p className="text-gray-400 mb-4">{seasonData.episodes.length} episodes</p>
            {seasonData.overview && <p className="text-gray-300 leading-relaxed mb-4">{seasonData.overview}</p>}
            {seasonData.air_date && (
              <p className="text-gray-400">First aired: {new Date(seasonData.air_date).toLocaleDateString()}</p>
            )}
          </div>
        </div>

        {/* Episodes List */}
        <div className="space-y-4">
          <h2 className="text-2xl font-bold mb-4">Episodes</h2>
          {seasonData.episodes.map((episode, index) => (
            <div
              key={episode.id}
              className="bg-gray-900 rounded-lg overflow-hidden border border-gray-800 hover:border-purple-500 transition-colors"
            >
              <div className="flex flex-col md:flex-row">
                {/* Episode Image */}
                <div className="w-full md:w-1/3 lg:w-1/4">
                  <div className="relative aspect-video">
                    {episode.still_path ? (
                      <Image
                        src={`https://image.tmdb.org/t/p/w500${episode.still_path}`}
                        alt={episode.name}
                        fill
                        className="object-cover"
                      />
                    ) : (
                      <div className="absolute inset-0 bg-gray-800 flex items-center justify-center">
                        <span className="text-gray-500">No Image</span>
                      </div>
                    )}

                    {/* Play Button Overlay */}
                    <div className="absolute inset-0 bg-black/40 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Button onClick={() => handleWatchEpisode(episode)} className="bg-purple-600 hover:bg-purple-700">
                        <Play className="h-4 w-4 mr-2" />
                        Watch
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Episode Info */}
                <div className="flex-1 p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg font-semibold">
                      {episode.episode_number}. {episode.name}
                    </h3>
                    <Button onClick={() => handleWatchEpisode(episode)} size="sm" className="ml-4">
                      <Play className="h-4 w-4 mr-1" />
                      Watch
                    </Button>
                  </div>

                  <div className="flex items-center gap-4 text-sm text-gray-400 mb-2">
                    {episode.air_date && (
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        {new Date(episode.air_date).toLocaleDateString()}
                      </div>
                    )}
                    {episode.runtime && (
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        {episode.runtime}m
                      </div>
                    )}
                    {episode.vote_average > 0 && (
                      <div className="flex items-center">⭐ {episode.vote_average.toFixed(1)}</div>
                    )}
                  </div>

                  {episode.overview && (
                    <p className="text-gray-300 text-sm leading-relaxed line-clamp-3">{episode.overview}</p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Episode Player */}
      {showPlayer && currentEpisode && (
        <EpisodePlayer
          showTitle={showTitle}
          seasonNumber={seasonData.season_number}
          episodeNumber={currentEpisode.episode_number}
          episodeTitle={currentEpisode.name}
          embedUrl={`https://vidsrc.me/embed/tv?tmdb=${params.id}&season=${seasonData.season_number}&episode=${currentEpisode.episode_number}`}
          onClose={() => setShowPlayer(false)}
          onNextEpisode={handleNextEpisode}
          onPreviousEpisode={handlePreviousEpisode}
          hasNextEpisode={hasNextEpisode()}
          hasPreviousEpisode={hasPreviousEpisode()}
        />
      )}
    </main>
  )
}
