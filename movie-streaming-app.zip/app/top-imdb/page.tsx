import { getMovies } from "@/lib/api"
import MovieCard from "@/components/movie-card"

export default async function TopIMDbPage() {
  // In a real app, you'd fetch top-rated movies from IMDb or TMDb
  const movies = await getMovies(1)
  const topRatedMovies = movies
    .filter((movie) => movie.vote_average >= 7.5)
    .sort((a, b) => b.vote_average - a.vote_average)

  return (
    <main className="min-h-screen bg-black text-white pt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold mb-8 text-center">
            <span className="bg-gradient-to-r from-yellow-500 to-orange-500 bg-clip-text text-transparent">
              Top IMDb Rated
            </span>
          </h1>

          <p className="text-gray-400 text-center mb-8 max-w-2xl mx-auto">
            Discover the highest-rated movies according to IMDb users. These films have stood the test of time and
            earned critical acclaim.
          </p>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4 md:gap-6">
            {topRatedMovies.map((movie, index) => (
              <div key={movie.id} className="relative">
                <div className="absolute -top-2 -left-2 bg-gradient-to-r from-yellow-500 to-orange-500 text-black w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold z-10">
                  {index + 1}
                </div>
                <MovieCard movie={movie} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}
