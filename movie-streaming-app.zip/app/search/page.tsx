import { searchMovies } from "@/lib/api"
import { searchTVShows } from "@/lib/api-tv"
import MovieCard from "@/components/movie-card"
import TVShowCard from "@/components/tv-show-card"
import { EnhancedSearch } from "@/components/enhanced-search"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default async function SearchPage({
  searchParams,
}: {
  searchParams: { q: string; page?: string }
}) {
  const query = searchParams.q
  const page = searchParams.page ? Number.parseInt(searchParams.page) : 1

  let movies: any[] = []
  let tvShows: any[] = []
  let error: string | null = null

  if (query) {
    try {
      const [movieResults, tvResults] = await Promise.all([
        searchMovies(query, page).catch(() => []),
        searchTVShows(query, page).catch(() => []),
      ])
      movies = movieResults
      tvShows = tvResults
    } catch (err) {
      console.error("Search error:", err)
      error = "Search failed. Please try again."
    }
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <EnhancedSearch />
      {query ? (
        <>
          <h2 className="text-xl font-semibold mb-4">
            Search results for: <span className="text-purple-400">{query}</span>
          </h2>

          {error ? (
            <div className="text-center py-12">
              <p className="text-red-400">{error}</p>
            </div>
          ) : (
            <Tabs defaultValue="all" className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-gray-900 mb-8">
                <TabsTrigger value="all">All ({movies.length + tvShows.length})</TabsTrigger>
                <TabsTrigger value="movies">Movies ({movies.length})</TabsTrigger>
                <TabsTrigger value="tv">TV Shows ({tvShows.length})</TabsTrigger>
              </TabsList>

              <TabsContent value="all">
                {movies.length > 0 || tvShows.length > 0 ? (
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
                    {[...movies, ...tvShows].map((item) =>
                      "title" in item ? (
                        <MovieCard key={`movie-${item.id}`} movie={item} />
                      ) : (
                        <TVShowCard key={`tv-${item.id}`} show={item} />
                      ),
                    )}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <p className="text-gray-400">No results found for "{query}"</p>
                    <p className="text-sm text-gray-500 mt-2">Try different keywords or check your spelling</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="movies">
                {movies.length > 0 ? (
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
                    {movies.map((movie) => (
                      <MovieCard key={movie.id} movie={movie} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <p className="text-gray-400">No movies found for "{query}"</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="tv">
                {tvShows.length > 0 ? (
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
                    {tvShows.map((show) => (
                      <TVShowCard key={show.id} show={show} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <p className="text-gray-400">No TV shows found for "{query}"</p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          )}
        </>
      ) : (
        <div className="text-center py-12">
          <p className="text-gray-400">Enter a search term to find movies and TV shows</p>
        </div>
      )}
    </main>
  )
}
