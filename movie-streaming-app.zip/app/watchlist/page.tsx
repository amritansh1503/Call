"use client"

import { useState, useEffect } from "react"
import { Trash2, Play } from "lucide-react"
import { Button } from "@/components/ui/button"
import { VideoPlayer } from "@/components/video-player"
import Link from "next/link"

interface WatchlistItem {
  id: number
  type: "movie" | "tv"
  title: string
  addedAt: string
}

export default function WatchlistPage() {
  const [watchlist, setWatchlist] = useState<WatchlistItem[]>([])
  const [selectedItem, setSelectedItem] = useState<WatchlistItem | null>(null)
  const [showPlayer, setShowPlayer] = useState(false)

  useEffect(() => {
    const savedWatchlist = JSON.parse(localStorage.getItem("watchlist") || "[]")
    setWatchlist(savedWatchlist)
  }, [])

  const removeFromWatchlist = (itemId: number, itemType: string) => {
    const updatedWatchlist = watchlist.filter((item) => !(item.id === itemId && item.type === itemType))
    setWatchlist(updatedWatchlist)
    localStorage.setItem("watchlist", JSON.stringify(updatedWatchlist))
  }

  const playItem = (item: WatchlistItem) => {
    setSelectedItem(item)
    setShowPlayer(true)
  }

  const getEmbedUrl = (item: WatchlistItem) => {
    if (item.type === "movie") {
      return `https://vidsrc.me/embed/movie?tmdb=${item.id}`
    } else {
      return `https://vidsrc.me/embed/tv?tmdb=${item.id}`
    }
  }

  if (watchlist.length === 0) {
    return (
      <main className="min-h-screen bg-black text-white">
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-3xl font-bold mb-8">My Watchlist</h1>
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📺</div>
            <h2 className="text-xl font-semibold mb-2">Your watchlist is empty</h2>
            <p className="text-gray-400 mb-6">
              Start adding movies and TV shows to keep track of what you want to watch.
            </p>
            <Link href="/">
              <Button>Browse Movies & Shows</Button>
            </Link>
          </div>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">My Watchlist</h1>

        <div className="grid gap-4">
          {watchlist.map((item) => (
            <div
              key={`${item.type}-${item.id}`}
              className="bg-gray-900 rounded-lg p-4 flex items-center justify-between"
            >
              <div className="flex items-center space-x-4">
                <div className="w-16 h-24 bg-gray-800 rounded flex items-center justify-center">
                  <span className="text-2xl">{item.type === "movie" ? "🎬" : "📺"}</span>
                </div>
                <div>
                  <h3 className="font-semibold">{item.title}</h3>
                  <p className="text-sm text-gray-400 capitalize">{item.type}</p>
                  <p className="text-xs text-gray-500">Added {new Date(item.addedAt).toLocaleDateString()}</p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Button size="sm" onClick={() => playItem(item)} className="bg-purple-600 hover:bg-purple-700">
                  <Play className="h-4 w-4 mr-1" />
                  Watch
                </Button>
                <Link href={`/${item.type}/${item.id}`}>
                  <Button variant="outline" size="sm">
                    Details
                  </Button>
                </Link>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeFromWatchlist(item.id, item.type)}
                  className="text-red-400 hover:text-red-300"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showPlayer && selectedItem && (
        <VideoPlayer
          title={selectedItem.title}
          embedUrl={getEmbedUrl(selectedItem)}
          onClose={() => setShowPlayer(false)}
          movieId={selectedItem.type === "movie" ? selectedItem.id : undefined}
          showId={selectedItem.type === "tv" ? selectedItem.id : undefined}
        />
      )}
    </main>
  )
}
