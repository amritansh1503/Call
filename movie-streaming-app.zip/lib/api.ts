import type { Movie, MovieDetails } from "./types"

// API key from environment variable
const API_KEY = process.env.TMDB_API_KEY || "ae4bd1b6fce2a5648671bfc171d15ba4"

// Helper function to retry failed requests
async function fetchWithRetry(url: string, options: RequestInit = {}, retries = 2, delay = 500) {
  const controller = new AbortController()
  const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 second timeout

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
      // Add performance optimizations
      headers: {
        ...options.headers,
        Accept: "application/json",
        "Accept-Encoding": "gzip, deflate, br",
        "Cache-Control": "max-age=3600",
      },
    })

    clearTimeout(timeoutId)

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`)
    }
    return response
  } catch (error) {
    clearTimeout(timeoutId)
    if (retries <= 1) throw error
    console.log(`Fetch failed, retrying in ${delay}ms... (${retries - 1} retries left)`)
    await new Promise((resolve) => setTimeout(resolve, delay))
    return fetchWithRetry(url, options, retries - 1, delay * 1.2)
  }
}

// Function to get movies from our PHP backend
export async function getMovies(page = 1): Promise<Movie[]> {
  try {
    // Try to use the PHP API first
    const phpApiUrl = process.env.PHP_API_URL || "/api/movies"
    try {
      const response = await fetchWithRetry(`${phpApiUrl}?page=${page}`, {
        next: { revalidate: 7200 }, // Cache for 2 hours
        headers: {
          Accept: "application/json",
        },
      })
      const data = await response.json()
      return data.results || []
    } catch (phpError) {
      console.warn("PHP API failed, falling back to direct TMDb API:", phpError)

      // Fallback to direct TMDb API
      const response = await fetchWithRetry(
        `https://api.themoviedb.org/3/movie/popular?api_key=${API_KEY}&page=${page}`,
        {
          next: { revalidate: 7200 }, // Cache for 2 hours
          headers: {
            Accept: "application/json",
          },
        },
      )
      const data = await response.json()
      return data.results || []
    }
  } catch (error) {
    console.error("Error fetching movies:", error)
    // Return mock data as a last resort
    return getMockMovies()
  }
}

// Function to get movie details
export async function getMovieDetails(id: string): Promise<MovieDetails | null> {
  try {
    // Try PHP API first
    const phpApiUrl = process.env.PHP_API_URL || "/api/movie"
    try {
      const response = await fetchWithRetry(`${phpApiUrl}/${id}`, {
        next: { revalidate: 7200 }, // Cache for 2 hours
        headers: {
          Accept: "application/json",
        },
      })
      return await response.json()
    } catch (phpError) {
      console.warn("PHP API failed, falling back to direct TMDb API:", phpError)

      // Fallback to direct TMDb API
      const response = await fetchWithRetry(
        `https://api.themoviedb.org/3/movie/${id}?api_key=${API_KEY}&append_to_response=credits,videos`,
        {
          next: { revalidate: 7200 }, // Cache for 2 hours
          headers: {
            Accept: "application/json",
          },
        },
      )

      if (!response.ok) {
        if (response.status === 404) {
          return null
        }
        throw new Error(`Failed to fetch movie details: ${response.status}`)
      }

      return await response.json()
    }
  } catch (error) {
    console.error(`Error fetching movie ${id}:`, error)
    return null
  }
}

// Function to search movies
export async function searchMovies(query: string, page = 1): Promise<Movie[]> {
  try {
    if (!query.trim()) {
      return []
    }

    // Try PHP API first
    const phpApiUrl = process.env.PHP_API_URL || "/api/search"
    try {
      const response = await fetchWithRetry(`${phpApiUrl}?query=${encodeURIComponent(query)}&page=${page}`, {
        next: { revalidate: 600 }, // Cache for 10 minutes for search results
        headers: {
          Accept: "application/json",
        },
      })
      const data = await response.json()
      console.log(`Movie search for "${query}": ${data.results?.length || 0} results`)
      return data.results || []
    } catch (phpError) {
      console.warn("PHP API failed, falling back to direct TMDb API:", phpError)

      // Fallback to direct TMDb API
      const response = await fetchWithRetry(
        `https://api.themoviedb.org/3/search/movie?api_key=${API_KEY}&query=${encodeURIComponent(query)}&page=${page}`,
        {
          next: { revalidate: 600 }, // Cache for 10 minutes for search results
          headers: {
            Accept: "application/json",
          },
        },
      )

      if (!response.ok) {
        console.error(`Movie search API error: ${response.status}`)
        return []
      }

      const data = await response.json()
      console.log(`Movie search for "${query}": ${data.results?.length || 0} results`)
      return data.results || []
    }
  } catch (error) {
    console.error("Error searching movies:", error)
    return []
  }
}

// Mock data as a last resort fallback
function getMockMovies(): Movie[] {
  return [
    {
      id: 1,
      title: "Sample Movie 1",
      poster_path: "/placeholder.svg?height=450&width=300",
      backdrop_path: "/placeholder.svg?height=800&width=1920",
      overview:
        "This is a sample movie when API is unavailable. Experience an epic adventure in this thrilling blockbuster.",
      release_date: "2023-01-01",
      vote_average: 7.5,
      genre_ids: [28, 12, 878], // Action, Adventure, Science Fiction
    },
    {
      id: 2,
      title: "Sample Movie 2",
      poster_path: "/placeholder.svg?height=450&width=300",
      backdrop_path: "/placeholder.svg?height=800&width=1920",
      overview:
        "Another sample movie for fallback purposes. A heartwarming story that will captivate audiences of all ages.",
      release_date: "2023-02-15",
      vote_average: 8.0,
      genre_ids: [18, 10749], // Drama, Romance
    },
    {
      id: 3,
      title: "Sample Movie 3",
      poster_path: "/placeholder.svg?height=450&width=300",
      backdrop_path: "/placeholder.svg?height=800&width=1920",
      overview: "A thrilling mystery that keeps you on the edge of your seat until the very last moment.",
      release_date: "2023-03-20",
      vote_average: 7.8,
      genre_ids: [9648, 53], // Mystery, Thriller
    },
    {
      id: 4,
      title: "Sample Movie 4",
      poster_path: "/placeholder.svg?height=450&width=300",
      backdrop_path: "/placeholder.svg?height=800&width=1920",
      overview: "A hilarious comedy that brings laughter and joy to the whole family.",
      release_date: "2023-04-10",
      vote_average: 6.9,
      genre_ids: [35, 10751], // Comedy, Family
    },
    {
      id: 5,
      title: "Sample Movie 5",
      poster_path: "/placeholder.svg?height=450&width=300",
      backdrop_path: "/placeholder.svg?height=800&width=1920",
      overview: "An intense horror film that will haunt your dreams and keep you awake at night.",
      release_date: "2023-05-05",
      vote_average: 7.2,
      genre_ids: [27, 53], // Horror, Thriller
    },
    {
      id: 6,
      title: "Sample Movie 6",
      poster_path: "/placeholder.svg?height=450&width=300",
      backdrop_path: "/placeholder.svg?height=800&width=1920",
      overview: "A beautiful animated adventure that takes you to magical worlds beyond imagination.",
      release_date: "2023-06-15",
      vote_average: 8.5,
      genre_ids: [16, 10751, 14], // Animation, Family, Fantasy
    },
  ]
}
