export interface Movie {
  id: number
  title: string
  poster_path: string | null
  backdrop_path: string | null
  overview: string
  release_date: string
  vote_average: number
  genre_ids: number[]
}

export interface MovieDetails extends Movie {
  genres: Genre[]
  runtime: number
  status: string
  tagline: string
  credits?: {
    cast: Cast[]
    crew: any[]
  }
  videos?: {
    results: Video[]
  }
}

export interface TVShow {
  id: number
  name: string
  poster_path: string | null
  backdrop_path: string | null
  overview: string
  first_air_date: string
  vote_average: number
  genre_ids: number[]
}

export interface TVShowDetails extends TVShow {
  genres: any[]
  episode_run_time: number[]
  number_of_seasons: number
  number_of_episodes: number
  status: string
  tagline: string
  credits?: {
    cast: any[]
    crew: any[]
  }
  videos?: {
    results: any[]
  }
  seasons: Season[]
}

export interface Season {
  id: number
  name: string
  overview: string
  poster_path: string | null
  season_number: number
  episode_count: number
  air_date: string
}

// Declare missing interfaces
export interface Genre {
  id: number
  name: string
}

export interface Cast {
  id: number
  name: string
  character: string
  profile_path: string | null
}

export interface Video {
  id: string
  iso_639_1: string
  iso_3166_1: string
  key: string
  name: string
  site: string
  size: number
  type: string
}
