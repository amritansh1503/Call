import type { TVShow, TVShowDetails } from "./types"

// API key from environment variable
const API_KEY = process.env.TMDB_API_KEY || "ae4bd1b6fce2a5648671bfc171d15ba4"

// Helper function to retry failed requests
async function fetchWithRetry(url: string, options: RequestInit = {}, retries = 2, delay = 500) {
  const controller = new AbortController()
  const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 second timeout

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
      // Add performance optimizations
      headers: {
        ...options.headers,
        Accept: "application/json",
        "Accept-Encoding": "gzip, deflate, br",
        "Cache-Control": "max-age=3600",
      },
    })

    clearTimeout(timeoutId)

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`)
    }
    return response
  } catch (error) {
    clearTimeout(timeoutId)
    if (retries <= 1) throw error
    console.log(`TV API fetch failed, retrying in ${delay}ms... (${retries - 1} retries left)`)
    await new Promise((resolve) => setTimeout(resolve, delay))
    return fetchWithRetry(url, options, retries - 1, delay * 1.2)
  }
}

// Function to get TV shows
export async function getTVShows(page = 1): Promise<TVShow[]> {
  try {
    // Try PHP API first
    const phpApiUrl = process.env.PHP_API_URL || "/api/tv"
    try {
      const response = await fetchWithRetry(`${phpApiUrl}?page=${page}`, {
        next: { revalidate: 7200 }, // Cache for 2 hours
        headers: {
          Accept: "application/json",
        },
      })
      const data = await response.json()
      return data.results || []
    } catch (phpError) {
      console.warn("PHP TV API failed, falling back to direct TMDb API:", phpError)

      // Fallback to direct TMDb API
      const response = await fetchWithRetry(`https://api.themoviedb.org/3/tv/popular?api_key=${API_KEY}&page=${page}`, {
        next: { revalidate: 7200 }, // Cache for 2 hours
        headers: {
          Accept: "application/json",
        },
      })
      const data = await response.json()
      return data.results || []
    }
  } catch (error) {
    console.error("Error fetching TV shows:", error)
    // Return mock data as a last resort
    return getMockTVShows()
  }
}

// Function to get TV show details
export async function getTVShowDetails(id: string): Promise<TVShowDetails | null> {
  try {
    // Try PHP API first
    const phpApiUrl = process.env.PHP_API_URL || "/api/tv-show"
    try {
      const response = await fetchWithRetry(`${phpApiUrl}/${id}`, {
        next: { revalidate: 7200 }, // Cache for 2 hours
        headers: {
          Accept: "application/json",
        },
      })
      return await response.json()
    } catch (phpError) {
      console.warn("PHP TV API failed, falling back to direct TMDb API:", phpError)

      // Fallback to direct TMDb API
      const response = await fetchWithRetry(
        `https://api.themoviedb.org/3/tv/${id}?api_key=${API_KEY}&append_to_response=credits,videos`,
        {
          next: { revalidate: 7200 }, // Cache for 2 hours
          headers: {
            Accept: "application/json",
          },
        },
      )

      if (!response.ok) {
        if (response.status === 404) {
          return null
        }
        throw new Error(`Failed to fetch TV show details: ${response.status}`)
      }

      return await response.json()
    }
  } catch (error) {
    console.error(`Error fetching TV show ${id}:`, error)
    return null
  }
}

// Function to search TV shows
export async function searchTVShows(query: string, page = 1): Promise<TVShow[]> {
  try {
    if (!query.trim()) {
      return []
    }

    // Try PHP API first
    const phpApiUrl = process.env.PHP_API_URL || "/api/search"
    try {
      const response = await fetchWithRetry(`${phpApiUrl}?query=${encodeURIComponent(query)}&type=tv&page=${page}`, {
        next: { revalidate: 600 }, // Cache for 10 minutes for search results
        headers: {
          Accept: "application/json",
        },
      })
      const data = await response.json()
      console.log(`TV search for "${query}": ${data.results?.length || 0} results`)
      return data.results || []
    } catch (phpError) {
      console.warn("PHP TV search failed, falling back to direct TMDb API:", phpError)

      // Fallback to direct TMDb API
      const response = await fetchWithRetry(
        `https://api.themoviedb.org/3/search/tv?api_key=${API_KEY}&query=${encodeURIComponent(query)}&page=${page}`,
        {
          next: { revalidate: 600 }, // Cache for 10 minutes for search results
          headers: {
            Accept: "application/json",
          },
        },
      )

      if (!response.ok) {
        console.error(`TV search API error: ${response.status}`)
        return []
      }

      const data = await response.json()
      console.log(`TV search for "${query}": ${data.results?.length || 0} results`)
      return data.results || []
    }
  } catch (error) {
    console.error("Error searching TV shows:", error)
    return []
  }
}

// Function to get season details with episodes
export async function getSeasonDetails(showId: string, seasonNumber: string): Promise<any> {
  try {
    // Try PHP API first
    const phpApiUrl = process.env.PHP_API_URL || "/api/season"
    try {
      const response = await fetchWithRetry(`${phpApiUrl}?show_id=${showId}&season=${seasonNumber}`, {
        next: { revalidate: 7200 }, // Cache for 2 hours
        headers: {
          Accept: "application/json",
        },
      })
      return await response.json()
    } catch (phpError) {
      console.warn("PHP season API failed, falling back to direct TMDb API:", phpError)

      // Fallback to direct TMDb API
      const response = await fetchWithRetry(
        `https://api.themoviedb.org/3/tv/${showId}/season/${seasonNumber}?api_key=${API_KEY}`,
        {
          next: { revalidate: 7200 }, // Cache for 2 hours
          headers: {
            Accept: "application/json",
          },
        },
      )

      if (!response.ok) {
        if (response.status === 404) {
          return null
        }
        throw new Error(`Failed to fetch season details: ${response.status}`)
      }

      const seasonData = await response.json()

      // Also get the show name
      const showResponse = await fetchWithRetry(`https://api.themoviedb.org/3/tv/${showId}?api_key=${API_KEY}`, {
        next: { revalidate: 7200 },
        headers: {
          Accept: "application/json",
        },
      })

      if (showResponse.ok) {
        const showData = await showResponse.json()
        seasonData.show_name = showData.name
      }

      return seasonData
    }
  } catch (error) {
    console.error(`Error fetching season ${seasonNumber} for show ${showId}:`, error)
    return null
  }
}

// Mock TV shows data as a last resort fallback
function getMockTVShows(): TVShow[] {
  return [
    {
      id: 1001,
      name: "Sample TV Show 1",
      poster_path: "/placeholder.svg?height=450&width=300",
      backdrop_path: "/placeholder.svg?height=800&width=1920",
      overview: "A thrilling drama series that follows the lives of complex characters in an ever-changing world.",
      first_air_date: "2023-01-15",
      vote_average: 8.2,
      genre_ids: [18, 9648], // Drama, Mystery
    },
    {
      id: 1002,
      name: "Sample TV Show 2",
      poster_path: "/placeholder.svg?height=450&width=300",
      backdrop_path: "/placeholder.svg?height=800&width=1920",
      overview: "A comedy series that brings laughter and joy to viewers with its witty humor and lovable characters.",
      first_air_date: "2023-02-20",
      vote_average: 7.8,
      genre_ids: [35, 10751], // Comedy, Family
    },
    {
      id: 1003,
      name: "Sample TV Show 3",
      poster_path: "/placeholder.svg?height=450&width=300",
      backdrop_path: "/placeholder.svg?height=800&width=1920",
      overview: "An action-packed series filled with adventure, suspense, and incredible special effects.",
      first_air_date: "2023-03-10",
      vote_average: 8.5,
      genre_ids: [28, 12, 878], // Action, Adventure, Sci-Fi
    },
    {
      id: 1004,
      name: "Sample TV Show 4",
      poster_path: "/placeholder.svg?height=450&width=300",
      backdrop_path: "/placeholder.svg?height=800&width=1920",
      overview: "A supernatural thriller that explores the unknown and keeps viewers on the edge of their seats.",
      first_air_date: "2023-04-05",
      vote_average: 7.9,
      genre_ids: [9648, 53, 10765], // Mystery, Thriller, Sci-Fi & Fantasy
    },
    {
      id: 1005,
      name: "Sample TV Show 5",
      poster_path: "/placeholder.svg?height=450&width=300",
      backdrop_path: "/placeholder.svg?height=800&width=1920",
      overview: "A romantic drama that tells beautiful love stories across different time periods.",
      first_air_date: "2023-05-12",
      vote_average: 8.0,
      genre_ids: [18, 10749], // Drama, Romance
    },
    {
      id: 1006,
      name: "Sample TV Show 6",
      poster_path: "/placeholder.svg?height=450&width=300",
      backdrop_path: "/placeholder.svg?height=800&width=1920",
      overview: "An animated series that brings magical adventures to life for audiences of all ages.",
      first_air_date: "2023-06-18",
      vote_average: 8.7,
      genre_ids: [16, 10751, 14], // Animation, Family, Fantasy
    },
  ]
}
