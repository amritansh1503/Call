"use client"

import { useState, useEffect } from "react"
import { Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"

interface RatingSystemProps {
  movieId?: number
  showId?: number
  title: string
}

interface UserRating {
  id: number
  type: "movie" | "tv"
  rating: number
  review?: string
  createdAt: string
}

export function RatingSystem({ movieId, showId, title }: RatingSystemProps) {
  const [userRating, setUserRating] = useState(0)
  const [hoverRating, setHoverRating] = useState(0)
  const [review, setReview] = useState("")
  const [showReviewForm, setShowReviewForm] = useState(false)
  const [existingRating, setExistingRating] = useState<UserRating | null>(null)
  const { toast } = useToast()

  const itemId = movieId || showId
  const itemType = movieId ? "movie" : "tv"

  useEffect(() => {
    // Load existing rating
    const ratings = JSON.parse(localStorage.getItem("userRatings") || "[]")
    const existing = ratings.find((r: UserRating) => r.id === itemId && r.type === itemType)

    if (existing) {
      setExistingRating(existing)
      setUserRating(existing.rating)
      setReview(existing.review || "")
    }
  }, [itemId, itemType])

  const handleRatingClick = (rating: number) => {
    setUserRating(rating)
    if (rating > 0) {
      setShowReviewForm(true)
    }
  }

  const submitRating = () => {
    const ratings = JSON.parse(localStorage.getItem("userRatings") || "[]")

    const newRating: UserRating = {
      id: itemId!,
      type: itemType,
      rating: userRating,
      review: review.trim() || undefined,
      createdAt: new Date().toISOString(),
    }

    // Remove existing rating if any
    const filteredRatings = ratings.filter((r: UserRating) => !(r.id === itemId && r.type === itemType))

    filteredRatings.push(newRating)
    localStorage.setItem("userRatings", JSON.stringify(filteredRatings))

    setExistingRating(newRating)
    setShowReviewForm(false)

    toast({
      title: "Rating Submitted",
      description: `Your ${userRating}-star rating for ${title} has been saved.`,
    })
  }

  const deleteRating = () => {
    const ratings = JSON.parse(localStorage.getItem("userRatings") || "[]")
    const filteredRatings = ratings.filter((r: UserRating) => !(r.id === itemId && r.type === itemType))

    localStorage.setItem("userRatings", JSON.stringify(filteredRatings))
    setExistingRating(null)
    setUserRating(0)
    setReview("")
    setShowReviewForm(false)

    toast({
      title: "Rating Deleted",
      description: `Your rating for ${title} has been removed.`,
    })
  }

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold mb-2">Rate this {itemType === "movie" ? "Movie" : "Show"}</h3>

        <div className="flex items-center space-x-1">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              onClick={() => handleRatingClick(star)}
              onMouseEnter={() => setHoverRating(star)}
              onMouseLeave={() => setHoverRating(0)}
              className="p-1 transition-colors"
            >
              <Star
                className={`h-6 w-6 ${
                  star <= (hoverRating || userRating) ? "text-yellow-400 fill-current" : "text-gray-400"
                }`}
              />
            </button>
          ))}
          {userRating > 0 && <span className="ml-2 text-sm text-gray-400">{userRating}/5 stars</span>}
        </div>
      </div>

      {showReviewForm && (
        <div className="space-y-3">
          <Textarea
            placeholder="Write a review (optional)..."
            value={review}
            onChange={(e) => setReview(e.target.value)}
            className="bg-gray-800 border-gray-700 text-white"
            rows={3}
          />
          <div className="flex space-x-2">
            <Button onClick={submitRating} size="sm">
              Submit Rating
            </Button>
            <Button variant="outline" size="sm" onClick={() => setShowReviewForm(false)}>
              Cancel
            </Button>
          </div>
        </div>
      )}

      {existingRating && !showReviewForm && (
        <div className="bg-gray-800 rounded-lg p-4">
          <div className="flex justify-between items-start mb-2">
            <h4 className="font-medium">Your Rating</h4>
            <div className="flex space-x-2">
              <Button variant="ghost" size="sm" onClick={() => setShowReviewForm(true)}>
                Edit
              </Button>
              <Button variant="ghost" size="sm" onClick={deleteRating} className="text-red-400 hover:text-red-300">
                Delete
              </Button>
            </div>
          </div>

          <div className="flex items-center space-x-1 mb-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star
                key={star}
                className={`h-4 w-4 ${
                  star <= existingRating.rating ? "text-yellow-400 fill-current" : "text-gray-400"
                }`}
              />
            ))}
            <span className="ml-2 text-sm text-gray-400">{existingRating.rating}/5 stars</span>
          </div>

          {existingRating.review && <p className="text-gray-300 text-sm">{existingRating.review}</p>}

          <p className="text-xs text-gray-500 mt-2">
            Rated on {new Date(existingRating.createdAt).toLocaleDateString()}
          </p>
        </div>
      )}
    </div>
  )
}
