"use client"

import { useState, useEffect } from "react"
import { Plus, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"

interface WatchlistButtonProps {
  movieId?: number
  showId?: number
  title: string
  variant?: "default" | "outline" | "ghost"
  size?: "default" | "sm" | "lg"
  className?: string
}

export function WatchlistButton({
  movieId,
  showId,
  title,
  variant = "outline",
  size = "default",
  className = "",
}: WatchlistButtonProps) {
  const [isInWatchlist, setIsInWatchlist] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const itemId = movieId || showId
  const itemType = movieId ? "movie" : "tv"

  useEffect(() => {
    // Check if item is in watchlist
    const watchlist = JSON.parse(localStorage.getItem("watchlist") || "[]")
    const isInList = watchlist.some((item: any) => item.id === itemId && item.type === itemType)
    setIsInWatchlist(isInList)
  }, [itemId, itemType])

  const toggleWatchlist = async () => {
    setIsLoading(true)

    try {
      const watchlist = JSON.parse(localStorage.getItem("watchlist") || "[]")

      if (isInWatchlist) {
        // Remove from watchlist
        const updatedWatchlist = watchlist.filter((item: any) => !(item.id === itemId && item.type === itemType))
        localStorage.setItem("watchlist", JSON.stringify(updatedWatchlist))
        setIsInWatchlist(false)

        toast({
          title: "Removed from Watchlist",
          description: `${title} has been removed from your watchlist.`,
        })
      } else {
        // Add to watchlist
        const newItem = {
          id: itemId,
          type: itemType,
          title,
          addedAt: new Date().toISOString(),
        }
        watchlist.push(newItem)
        localStorage.setItem("watchlist", JSON.stringify(watchlist))
        setIsInWatchlist(true)

        toast({
          title: "Added to Watchlist",
          description: `${title} has been added to your watchlist.`,
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update watchlist. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Button variant={variant} size={size} onClick={toggleWatchlist} disabled={isLoading} className={className}>
      {isInWatchlist ? (
        <>
          <Check className="h-4 w-4 mr-2" />
          In Watchlist
        </>
      ) : (
        <>
          <Plus className="h-4 w-4 mr-2" />
          Add to Watchlist
        </>
      )}
    </Button>
  )
}
