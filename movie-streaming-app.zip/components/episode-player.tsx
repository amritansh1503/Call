"use client"

import { useState, useEffect } from "react"
import { X, SkipBack, SkipForward, AlertCircle, CheckCircle, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"

interface EpisodePlayerProps {
  showTitle: string
  seasonNumber: number
  episodeNumber: number
  episodeTitle: string
  embedUrl: string
  onClose: () => void
  onNextEpisode?: () => void
  onPreviousEpisode?: () => void
  hasNextEpisode?: boolean
  hasPreviousEpisode?: boolean
  showId?: number
}

export function EpisodePlayer({
  showTitle,
  seasonNumber,
  episodeNumber,
  episodeTitle,
  embedUrl,
  onClose,
  onNextEpisode,
  onPreviousEpisode,
  hasNextEpisode = false,
  hasPreviousEpisode = false,
  showId,
}: EpisodePlayerProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [videoError, setVideoError] = useState(false)
  const [retryCount, setRetryCount] = useState(0)

  useEffect(() => {
    // Prevent body scroll when modal is open
    document.body.style.overflow = "hidden"

    // Handle escape key
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose()
      }
    }

    // Handle arrow keys for episode navigation
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" && hasNextEpisode && onNextEpisode) {
        onNextEpisode()
      } else if (e.key === "ArrowLeft" && hasPreviousEpisode && onPreviousEpisode) {
        onPreviousEpisode()
      }
    }

    document.addEventListener("keydown", handleEscape)
    document.addEventListener("keydown", handleKeyDown)

    return () => {
      document.body.style.overflow = "unset"
      document.removeEventListener("keydown", handleEscape)
      document.removeEventListener("keydown", handleKeyDown)
    }
  }, [onClose, onNextEpisode, onPreviousEpisode, hasNextEpisode, hasPreviousEpisode])

  // Reset loading state when episode changes
  useEffect(() => {
    setIsLoading(true)
    setVideoError(false)
    setRetryCount(0)
  }, [showId, seasonNumber, episodeNumber])

  const getMoviesApiUrl = () => {
    if (showId) {
      return `https://moviesapi.club/tv/${showId}-${seasonNumber}-${episodeNumber}`
    }
    return null
  }

  const handleIframeLoad = () => {
    console.log("Episode loaded successfully")
    setIsLoading(false)
    setVideoError(false)
  }

  const handleIframeError = () => {
    console.error("Episode failed to load")
    setIsLoading(false)
    setVideoError(true)
  }

  const handleRetry = () => {
    setRetryCount((prev) => prev + 1)
    setIsLoading(true)
    setVideoError(false)
  }

  const handleNextEpisode = () => {
    if (onNextEpisode) {
      onNextEpisode()
    }
  }

  const handlePreviousEpisode = () => {
    if (onPreviousEpisode) {
      onPreviousEpisode()
    }
  }

  const moviesApiUrl = getMoviesApiUrl()
  const title = `${showTitle} - S${seasonNumber}E${episodeNumber}: ${episodeTitle}`

  return (
    <div className="fixed inset-0 z-50 bg-black flex items-center justify-center">
      {/* Video Container */}
      <div className="relative w-full h-full max-w-7xl mx-auto">
        {/* Header */}
        <div className="absolute top-0 left-0 right-0 z-20 p-4 bg-gradient-to-b from-black/80 to-transparent">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-white text-xl font-semibold">{showTitle}</h2>
              <p className="text-gray-300 text-sm">
                Season {seasonNumber} • Episode {episodeNumber}
              </p>
              <p className="text-gray-400 text-sm truncate">{episodeTitle}</p>
              <div className="flex items-center gap-2 mt-1">
                <p className="text-teal-400 text-sm">Server: MoviesAPI.club</p>
                {!isLoading && !videoError && <CheckCircle className="h-4 w-4 text-green-500" />}
                {videoError && <AlertCircle className="h-4 w-4 text-red-500" />}
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {videoError && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleRetry}
                  className="text-white hover:bg-white/20"
                  title="Retry"
                >
                  <RotateCcw className="h-5 w-5" />
                </Button>
              )}
              <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-white/20">
                <X className="h-6 w-6" />
              </Button>
            </div>
          </div>
        </div>

        {/* Episode Navigation */}
        {!videoError && (
          <div className="absolute bottom-4 left-4 z-20 flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handlePreviousEpisode}
              disabled={!hasPreviousEpisode}
              className="text-white hover:bg-white/20 disabled:opacity-50 bg-black/60"
            >
              <SkipBack className="h-4 w-4 mr-1" />
              Previous
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleNextEpisode}
              disabled={!hasNextEpisode}
              className="text-white hover:bg-white/20 disabled:opacity-50 bg-black/60"
            >
              Next
              <SkipForward className="h-4 w-4 ml-1" />
            </Button>
          </div>
        )}

        {/* Main Content */}
        <div className="relative w-full h-full bg-black rounded-lg overflow-hidden">
          {moviesApiUrl && !videoError ? (
            <>
              <iframe
                key={`${moviesApiUrl}-${retryCount}`} // Force reload on retry
                src={moviesApiUrl}
                title={title}
                className="w-full h-full"
                allowFullScreen
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
                referrerPolicy="strict-origin-when-cross-origin"
                loading="eager"
                style={{ border: "none" }}
                onLoad={handleIframeLoad}
                onError={handleIframeError}
              />

              {/* Loading Indicator */}
              {isLoading && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/80 z-10">
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500 mb-4"></div>
                    <p className="text-white text-lg">Loading Episode...</p>
                    <p className="text-xs text-gray-400 mt-2">
                      S{seasonNumber}E{episodeNumber} • {episodeTitle}
                    </p>
                  </div>
                </div>
              )}
            </>
          ) : videoError ? (
            <div className="w-full h-full flex items-center justify-center bg-gray-900">
              <div className="text-center max-w-md mx-auto p-8">
                <div className="text-6xl mb-6">⚠️</div>
                <h3 className="text-2xl font-bold text-white mb-4">Episode Unavailable</h3>
                <p className="text-gray-300 mb-6 leading-relaxed">
                  Unable to load this episode. The content may not be available or there might be server issues.
                </p>

                <div className="bg-gray-800 rounded-lg p-4 mb-6">
                  <p className="text-xs text-gray-400 mb-2">Episode URL:</p>
                  <p className="text-sm text-teal-400 font-mono break-all">{moviesApiUrl}</p>
                </div>

                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Button
                    onClick={handleRetry}
                    className="bg-teal-600 hover:bg-teal-700 text-white font-semibold px-8 py-3"
                  >
                    <RotateCcw className="h-5 w-5 mr-2" />
                    Retry Episode
                  </Button>
                  <Button
                    onClick={() => window.open(moviesApiUrl, "_blank")}
                    variant="outline"
                    className="border-gray-600 text-white hover:bg-white/10 px-8 py-3"
                  >
                    Open in New Tab
                  </Button>
                  <Button
                    onClick={onClose}
                    variant="outline"
                    className="border-gray-600 text-white hover:bg-white/10 px-8 py-3"
                  >
                    Close
                  </Button>
                </div>

                <div className="mt-6 text-xs text-gray-500">
                  <p>Try the next/previous episode or open in a new tab if the issue persists.</p>
                </div>

                {/* Episode Navigation in Error State */}
                <div className="flex items-center justify-center space-x-2 mt-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handlePreviousEpisode}
                    disabled={!hasPreviousEpisode}
                    className="text-white hover:bg-white/20 disabled:opacity-50"
                  >
                    <SkipBack className="h-4 w-4 mr-1" />
                    Previous
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleNextEpisode}
                    disabled={!hasNextEpisode}
                    className="text-white hover:bg-white/20 disabled:opacity-50"
                  >
                    Next
                    <SkipForward className="h-4 w-4 ml-1" />
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gray-900">
              <div className="text-center">
                <div className="text-6xl mb-4">❌</div>
                <h3 className="text-xl font-semibold mb-2">Invalid Episode</h3>
                <p className="text-gray-400 mb-4">Unable to generate streaming URL for this episode.</p>
                <Button onClick={onClose} variant="outline">
                  Close
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
