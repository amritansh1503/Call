import { getMovies } from "@/lib/api"
import { getTVShows } from "@/lib/api-tv"
import { TrendingCarousel } from "@/components/trending-carousel"

export async function TrendingSection() {
  try {
    const [movies, tvShows] = await Promise.all([getMovies(1).catch(() => []), getTVShows(1).catch(() => [])])

    // Combine and shuffle movies and TV shows
    const allContent = [...movies.slice(0, 5), ...tvShows.slice(0, 5)].sort(() => Math.random() - 0.5)

    return (
      <div className="mt-12">
        <h2 className="text-2xl font-bold mb-6 text-center flex items-center justify-center">
          <span className="text-2xl mr-2">🔥</span>
          <span className="bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">
            Trending Now
          </span>
          <span className="text-2xl ml-2">🔥</span>
        </h2>
        <TrendingCarousel content={allContent} />
      </div>
    )
  } catch (error) {
    console.error("Error in TrendingSection:", error)
    return (
      <div className="mt-12">
        <h2 className="text-2xl font-bold mb-6 text-center">
          <span className="bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">
            Trending Now
          </span>
        </h2>
        <div className="text-center py-8">
          <p className="text-gray-400">Unable to load trending content</p>
        </div>
      </div>
    )
  }
}
