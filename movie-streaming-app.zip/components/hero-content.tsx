"use client"

import { useState } from "react"
import Image from "next/image"
import { Play, Plus, Info, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { VideoPlayer } from "@/components/video-player"
import type { Movie } from "@/lib/types"

interface HeroContentProps {
  movie: Movie
}

export function HeroContent({ movie }: HeroContentProps) {
  const [showPlayer, setShowPlayer] = useState(false)

  return (
    <>
      <div className="relative h-[70vh] overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <Image
            src={
              movie.backdrop_path
                ? `https://image.tmdb.org/t/p/original${movie.backdrop_path}`
                : "/placeholder.svg?height=1080&width=1920"
            }
            alt={movie.title}
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-transparent to-transparent" />
        </div>

        {/* Content */}
        <div className="relative z-10 h-full flex items-center">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl">
              <h1 className="text-4xl md:text-6xl font-bold mb-4 leading-tight">{movie.title}</h1>

              <div className="flex items-center space-x-4 mb-4">
                {movie.vote_average > 0 && (
                  <div className="flex items-center bg-yellow-500 text-black px-3 py-1 rounded-full">
                    <Star className="h-4 w-4 mr-1" fill="currentColor" />
                    <span className="font-bold">{Math.round(movie.vote_average * 10)}</span>
                  </div>
                )}
                <span className="text-gray-300">
                  {movie.release_date ? new Date(movie.release_date).getFullYear() : "Unknown"}
                </span>
                <span className="text-gray-300">Movie</span>
              </div>

              <p className="text-lg text-gray-300 mb-8 leading-relaxed line-clamp-3">{movie.overview}</p>

              <div className="flex items-center space-x-4">
                <Button
                  size="lg"
                  onClick={() => setShowPlayer(true)}
                  className="bg-white text-black hover:bg-gray-200 font-semibold px-8 py-3"
                >
                  <Play className="h-5 w-5 mr-2" fill="currentColor" />
                  Watch now
                </Button>
                <Button size="lg" variant="outline" className="border-gray-600 text-white hover:bg-white/10 px-8 py-3">
                  <Plus className="h-5 w-5 mr-2" />
                  My List
                </Button>
                <Button size="lg" variant="ghost" className="text-white hover:bg-white/10 px-8 py-3">
                  <Info className="h-5 w-5 mr-2" />
                  More Info
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showPlayer && (
        <VideoPlayer
          title={movie.title}
          embedUrl={`https://vidsrc.me/embed/movie?tmdb=${movie.id}`}
          onClose={() => setShowPlayer(false)}
          movieId={movie.id}
        />
      )}
    </>
  )
}
