import { getMovies } from "@/lib/api"
import { HeroContent } from "@/components/hero-content"
import { Suspense } from "react"

export async function HeroSection() {
  try {
    const movies = await getMovies(1)
    const featuredMovie = movies[0] // Use the first movie as featured

    if (!featuredMovie) {
      return (
        <div className="w-full aspect-video bg-gray-800 rounded-lg flex items-center justify-center">
          <p className="text-gray-400">Unable to load featured content</p>
        </div>
      )
    }

    return (
      <Suspense
        fallback={
          <div className="w-full aspect-video bg-gray-800 rounded-lg flex items-center justify-center">
            <div className="animate-pulse flex space-x-4">
              <div className="flex-1 space-y-6 py-1">
                <div className="h-4 bg-gray-700 rounded w-3/4"></div>
                <div className="space-y-3">
                  <div className="h-4 bg-gray-700 rounded"></div>
                  <div className="h-4 bg-gray-700 rounded w-5/6"></div>
                </div>
              </div>
            </div>
          </div>
        }
      >
        <HeroContent movie={featuredMovie} />
      </Suspense>
    )
  } catch (error) {
    console.error("Error in HeroSection:", error)
    return (
      <div className="w-full aspect-video bg-gray-800 rounded-lg flex items-center justify-center">
        <div className="text-center p-4">
          <h3 className="text-xl text-gray-300 mb-2">Unable to load content</h3>
          <p className="text-gray-400 text-sm">Please try again later</p>
        </div>
      </div>
    )
  }
}
