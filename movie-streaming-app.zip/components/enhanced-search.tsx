"use client"

import { useState, useEffect } from "react"
import { Search, Filter, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { searchMovies } from "@/lib/api"
import { searchTVShows } from "@/lib/api-tv"
import Image from "next/image"
import Link from "next/link"
import type { Movie, TVShow } from "@/lib/types"

interface SearchFilters {
  type: "all" | "movie" | "tv"
  genre: string
  year: string
  sortBy: "popularity" | "rating" | "release_date"
}

const GENRES = [
  { id: "28", name: "Action" },
  { id: "12", name: "Adventure" },
  { id: "16", name: "Animation" },
  { id: "35", name: "Comedy" },
  { id: "80", name: "Crime" },
  { id: "99", name: "Documentary" },
  { id: "18", name: "Drama" },
  { id: "10751", name: "Family" },
  { id: "14", name: "Fantasy" },
  { id: "36", name: "History" },
  { id: "27", name: "Horror" },
  { id: "10402", name: "Music" },
  { id: "9648", name: "Mystery" },
  { id: "10749", name: "Romance" },
  { id: "878", name: "Science Fiction" },
  { id: "10770", name: "TV Movie" },
  { id: "53", name: "Thriller" },
  { id: "10752", name: "War" },
  { id: "37", name: "Western" },
]

const YEARS = Array.from({ length: 30 }, (_, i) => (new Date().getFullYear() - i).toString())

interface EnhancedSearchProps {
  onClose?: () => void
  isDialog?: boolean
}

export function EnhancedSearch({ onClose, isDialog = false }: EnhancedSearchProps) {
  const [query, setQuery] = useState("")
  const [filters, setFilters] = useState<SearchFilters>({
    type: "all",
    genre: "",
    year: "",
    sortBy: "popularity",
  })
  const [movies, setMovies] = useState<Movie[]>([])
  const [tvShows, setTVShows] = useState<TVShow[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [showFilters, setShowFilters] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!query.trim()) {
      setMovies([])
      setTVShows([])
      setError(null)
      return
    }

    const searchContent = async () => {
      setIsLoading(true)
      setError(null)
      try {
        console.log("Searching for:", query, "with filters:", filters)

        let movieResults: Movie[] = []
        let tvResults: TVShow[] = []

        if (filters.type === "all" || filters.type === "movie") {
          try {
            movieResults = await searchMovies(query)
          } catch (err) {
            console.error("Movie search error:", err)
          }
        }

        if (filters.type === "all" || filters.type === "tv") {
          try {
            tvResults = await searchTVShows(query)
          } catch (err) {
            console.error("TV search error:", err)
          }
        }

        // Apply filters
        if (filters.genre) {
          movieResults = movieResults.filter((movie) => movie.genre_ids?.includes(Number.parseInt(filters.genre)))
          tvResults = tvResults.filter((show) => show.genre_ids?.includes(Number.parseInt(filters.genre)))
        }

        if (filters.year) {
          movieResults = movieResults.filter((movie) => movie.release_date?.startsWith(filters.year))
          tvResults = tvResults.filter((show) => show.first_air_date?.startsWith(filters.year))
        }

        // Apply sorting
        const sortFunction = (a: Movie | TVShow, b: Movie | TVShow) => {
          switch (filters.sortBy) {
            case "rating":
              return b.vote_average - a.vote_average
            case "release_date":
              const dateA = "release_date" in a ? a.release_date : a.first_air_date
              const dateB = "release_date" in b ? b.release_date : b.first_air_date
              return new Date(dateB || "").getTime() - new Date(dateA || "").getTime()
            default: // popularity
              return b.vote_average - a.vote_average // Using vote_average as popularity proxy
          }
        }

        movieResults.sort(sortFunction)
        tvResults.sort(sortFunction)

        console.log("Search results:", { movies: movieResults.length, tv: tvResults.length })

        setMovies(movieResults.slice(0, 10))
        setTVShows(tvResults.slice(0, 10))

        if (movieResults.length === 0 && tvResults.length === 0) {
          setError("No results found")
        }
      } catch (error) {
        console.error("Search error:", error)
        setError("Search failed. Please try again.")
      } finally {
        setIsLoading(false)
      }
    }

    const debounceTimer = setTimeout(searchContent, 300)
    return () => clearTimeout(debounceTimer)
  }, [query, filters])

  const clearFilters = () => {
    setFilters({
      type: "all",
      genre: "",
      year: "",
      sortBy: "popularity",
    })
  }

  const hasActiveFilters = filters.type !== "all" || filters.genre || filters.year || filters.sortBy !== "popularity"

  const containerClass = isDialog
    ? "max-w-4xl mx-auto"
    : "container mx-auto px-4 py-8 pt-20 min-h-screen bg-black text-white"

  return (
    <div className={containerClass}>
      {!isDialog && (
        <h1 className="text-3xl md:text-4xl font-bold mb-6">
          <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">Search</span>
        </h1>
      )}

      {/* Search Input */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
        <Input
          type="text"
          placeholder="Search for movies or TV shows..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="pl-10 bg-gray-900 border-gray-700 focus:border-cyan-500 text-white text-lg py-6"
          autoFocus={isDialog}
        />
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setShowFilters(!showFilters)}
          className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
        >
          <Filter className="h-5 w-5" />
        </Button>
      </div>

      {/* Filters */}
      {showFilters && (
        <Card className="mb-6 bg-gray-900 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Filters</h3>
              <div className="flex items-center space-x-2">
                {hasActiveFilters && (
                  <Button variant="ghost" size="sm" onClick={clearFilters} className="text-gray-400 hover:text-white">
                    Clear All
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowFilters(false)}
                  className="text-gray-400 hover:text-white"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Type</label>
                <Select value={filters.type} onValueChange={(value: any) => setFilters({ ...filters, type: value })}>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="movie">Movies</SelectItem>
                    <SelectItem value="tv">TV Shows</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Genre</label>
                <Select value={filters.genre} onValueChange={(value) => setFilters({ ...filters, genre: value })}>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue placeholder="All Genres" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="">All Genres</SelectItem>
                    {GENRES.map((genre) => (
                      <SelectItem key={genre.id} value={genre.id}>
                        {genre.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Year</label>
                <Select value={filters.year} onValueChange={(value) => setFilters({ ...filters, year: value })}>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue placeholder="All Years" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="">All Years</SelectItem>
                    {YEARS.map((year) => (
                      <SelectItem key={year} value={year}>
                        {year}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Sort By</label>
                <Select
                  value={filters.sortBy}
                  onValueChange={(value: any) => setFilters({ ...filters, sortBy: value })}
                >
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="popularity">Popularity</SelectItem>
                    <SelectItem value="rating">Rating</SelectItem>
                    <SelectItem value="release_date">Release Date</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search Results */}
      {query.trim() && (
        <div className="space-y-6">
          {isLoading && (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500 mx-auto"></div>
              <p className="text-gray-400 mt-2">Searching...</p>
            </div>
          )}

          {error && !isLoading && (
            <div className="text-center py-8">
              <p className="text-red-400">{error}</p>
              <p className="text-gray-500 text-sm mt-2">Try different keywords or adjust your filters</p>
            </div>
          )}

          {!isLoading && !error && movies.length === 0 && tvShows.length === 0 && (
            <div className="text-center py-8">
              <p className="text-gray-400">No results found for "{query}"</p>
              <p className="text-gray-500 text-sm mt-2">Try different keywords or adjust your filters</p>
            </div>
          )}

          {movies.length > 0 && (filters.type === "all" || filters.type === "movie") && (
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">Movies ({movies.length})</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                {movies.map((movie) => (
                  <Link
                    key={movie.id}
                    href={`/movie/${movie.id}`}
                    onClick={onClose}
                    className="group block bg-gray-900 rounded-lg overflow-hidden hover:bg-gray-800 transition-colors"
                  >
                    <div className="aspect-[2/3] relative">
                      <Image
                        src={
                          movie.poster_path
                            ? `https://image.tmdb.org/t/p/w300${movie.poster_path}`
                            : "/placeholder.svg?height=450&width=300"
                        }
                        alt={movie.title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform"
                      />
                    </div>
                    <div className="p-3">
                      <h4 className="font-medium text-white text-sm line-clamp-2">{movie.title}</h4>
                      <p className="text-xs text-gray-400 mt-1">
                        {movie.release_date ? new Date(movie.release_date).getFullYear() : "Unknown"} • Movie
                      </p>
                      <div className="flex items-center mt-1">
                        <span className="text-yellow-400 text-xs">★</span>
                        <span className="text-xs text-gray-400 ml-1">{movie.vote_average.toFixed(1)}</span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {tvShows.length > 0 && (filters.type === "all" || filters.type === "tv") && (
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">TV Shows ({tvShows.length})</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                {tvShows.map((show) => (
                  <Link
                    key={show.id}
                    href={`/tv/${show.id}`}
                    onClick={onClose}
                    className="group block bg-gray-900 rounded-lg overflow-hidden hover:bg-gray-800 transition-colors"
                  >
                    <div className="aspect-[2/3] relative">
                      <Image
                        src={
                          show.poster_path
                            ? `https://image.tmdb.org/t/p/w300${show.poster_path}`
                            : "/placeholder.svg?height=450&width=300"
                        }
                        alt={show.name}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform"
                      />
                    </div>
                    <div className="p-3">
                      <h4 className="font-medium text-white text-sm line-clamp-2">{show.name}</h4>
                      <p className="text-xs text-gray-400 mt-1">
                        {show.first_air_date ? new Date(show.first_air_date).getFullYear() : "Unknown"} • TV Show
                      </p>
                      <div className="flex items-center mt-1">
                        <span className="text-yellow-400 text-xs">★</span>
                        <span className="text-xs text-gray-400 ml-1">{show.vote_average.toFixed(1)}</span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
