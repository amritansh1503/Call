export function TrendingSkeleton() {
  return (
    <div className="mt-12">
      <div className="h-8 bg-gray-800 rounded w-48 mb-6 mx-auto animate-pulse" />
      <div className="flex space-x-4 overflow-hidden">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="w-64 h-96 bg-gray-800 rounded-lg animate-pulse flex-shrink-0" />
        ))}
      </div>
    </div>
  )
}
