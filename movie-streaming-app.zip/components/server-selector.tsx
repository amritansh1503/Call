"use client"

import { useState } from "react"
import { Server, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface ServerSelectorProps {
  movieId?: number
  showId?: number
  seasonNumber?: number
  episodeNumber?: number
  onServerChange: (url: string, serverName: string) => void
  currentServer?: string
}

interface VideoServer {
  name: string
  url: string
  quality: string
  description: string
  isExternal?: boolean
}

export function ServerSelector({
  movieId,
  showId,
  seasonNumber,
  episodeNumber,
  onServerChange,
  currentServer = "MoviesAPI",
}: ServerSelectorProps) {
  const [selectedServer, setSelectedServer] = useState(currentServer)

  const getServers = (): VideoServer[] => {
    if (movieId) {
      return [
        {
          name: "MoviesAPI",
          url: `https://moviesapi.club/movie/${movieId}`,
          quality: "4K",
          description: "External link (new tab)",
          isExternal: true,
        },
      ]
    } else {
      return [
        {
          name: "MoviesAPI",
          url: `https://moviesapi.club/tv/${showId}-${seasonNumber}-${episodeNumber}`,
          quality: "4K",
          description: "External link (new tab)",
          isExternal: true,
        },
      ]
    }
  }

  const servers = getServers()

  const handleServerSelect = (server: VideoServer) => {
    setSelectedServer(server.name)
    onServerChange(server.url, server.name)
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700">
          <Server className="h-4 w-4 mr-2" />
          {selectedServer}
          <ChevronDown className="h-4 w-4 ml-2" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-64 bg-gray-800 border-gray-700">
        {servers.map((server) => (
          <DropdownMenuItem
            key={server.name}
            onClick={() => handleServerSelect(server)}
            className={`text-white hover:bg-gray-700 cursor-pointer ${
              selectedServer === server.name ? "bg-teal-600/20" : ""
            }`}
          >
            <div className="flex justify-between items-center w-full">
              <div>
                <div className="font-medium">{server.name}</div>
                <div className="text-xs text-gray-400">{server.description}</div>
              </div>
              <div className="text-xs bg-teal-600 text-white px-2 py-1 rounded">{server.quality}</div>
            </div>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
