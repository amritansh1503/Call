import { getMovies } from "@/lib/api"
import MovieCard from "@/components/movie-card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default async function MovieGrid({ page = 1 }: { page?: number }) {
  const movies = await getMovies(page)

  if (!movies || movies.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-400">No movies found</p>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4 md:gap-6">
        {movies.map((movie) => (
          <MovieCard key={movie.id} movie={movie} />
        ))}
      </div>

      <div className="flex justify-center gap-4 pt-4">
        {page > 1 && (
          <Link href={`/?page=${page - 1}`}>
            <Button variant="outline" className="border-gray-600 text-white hover:bg-white/10">
              Previous
            </Button>
          </Link>
        )}
        <Link href={`/?page=${page + 1}`}>
          <Button variant="outline" className="border-gray-600 text-white hover:bg-white/10">
            Next
          </Button>
        </Link>
      </div>
    </div>
  )
}
