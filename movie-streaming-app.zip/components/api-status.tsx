"use client"

import { useState, useEffect } from "react"
import { AlertCircle } from "lucide-react"

export function ApiStatus() {
  const [status, setStatus] = useState<"loading" | "online" | "offline">("loading")
  const [message, setMessage] = useState<string>("")

  useEffect(() => {
    const checkApiStatus = async () => {
      try {
        const response = await fetch("/api/health-check")
        if (response.ok) {
          const data = await response.json()
          setStatus(data.status)
          setMessage(data.message || "")
        } else {
          setStatus("offline")
          setMessage("API service is currently unavailable")
        }
      } catch (error) {
        setStatus("offline")
        setMessage("Cannot connect to API services")
      }
    }

    checkApiStatus()
    const interval = setInterval(checkApiStatus, 60000) // Check every minute

    return () => clearInterval(interval)
  }, [])

  if (status === "loading") return null

  if (status === "offline") {
    return (
      <div className="bg-red-900/20 border border-red-800 text-red-300 px-4 py-2 rounded-md mb-4 flex items-center">
        <AlertCircle className="h-5 w-5 mr-2" />
        <span className="text-sm">{message || "API services are currently experiencing issues"}</span>
      </div>
    )
  }

  return null // Don't show anything when online
}
