import Link from "next/link"
import { Film, Github, Twitter } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-black/80 border-t border-gray-800 py-8 mt-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center space-x-2 mb-4 md:mb-0">
            <Film className="h-6 w-6 text-purple-500" />
            <span className="font-bold text-xl">MovieStream</span>
          </div>

          <div className="flex flex-col md:flex-row md:space-x-8 text-center md:text-left">
            <div className="mb-4 md:mb-0">
              <h3 className="font-semibold text-lg mb-2">Navigation</h3>
              <ul className="space-y-1 text-gray-400">
                <li>
                  <Link href="/" className="hover:text-purple-400">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/movies" className="hover:text-purple-400">
                    Movies
                  </Link>
                </li>
                <li>
                  <Link href="/tv" className="hover:text-purple-400">
                    TV Shows
                  </Link>
                </li>
                <li>
                  <Link href="/search" className="hover:text-purple-400">
                    Search
                  </Link>
                </li>
              </ul>
            </div>

            <div className="mb-4 md:mb-0">
              <h3 className="font-semibold text-lg mb-2">Legal</h3>
              <ul className="space-y-1 text-gray-400">
                <li>
                  <Link href="/terms" className="hover:text-purple-400">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-purple-400">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/dmca" className="hover:text-purple-400">
                    DMCA
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-lg mb-2">Connect</h3>
              <div className="flex justify-center md:justify-start space-x-4">
                <Link href="https://twitter.com" className="text-gray-400 hover:text-purple-400">
                  <Twitter className="h-5 w-5" />
                  <span className="sr-only">Twitter</span>
                </Link>
                <Link href="https://github.com" className="text-gray-400 hover:text-purple-400">
                  <Github className="h-5 w-5" />
                  <span className="sr-only">GitHub</span>
                </Link>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center text-gray-500 text-sm">
          <p>© {new Date().getFullYear()} MovieStream. All rights reserved.</p>
          <p className="mt-1">
            Powered by TMDb API. This product uses the TMDB API but is not endorsed or certified by TMDB.
          </p>
        </div>
      </div>
    </footer>
  )
}
