"use client"

import { useState, useEffect } from "react"
import { Search, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { searchMovies } from "@/lib/api"
import { searchTVShows } from "@/lib/api-tv"
import Image from "next/image"
import Link from "next/link"
import { EnhancedSearch } from "@/components/enhanced-search"
import type { Movie, TVShow } from "@/lib/types"

interface SearchDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function SearchDialog({ open, onOpenChange }: SearchDialogProps) {
  const [query, setQuery] = useState("")
  const [movies, setMovies] = useState<Movie[]>([])
  const [tvShows, setTVShows] = useState<TVShow[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!query.trim()) {
      setMovies([])
      setTVShows([])
      setError(null)
      return
    }

    const searchContent = async () => {
      setIsLoading(true)
      setError(null)
      try {
        console.log("Searching for:", query)
        const [movieResults, tvResults] = await Promise.all([
          searchMovies(query).catch((err) => {
            console.error("Movie search error:", err)
            return []
          }),
          searchTVShows(query).catch((err) => {
            console.error("TV search error:", err)
            return []
          }),
        ])

        console.log("Movie results:", movieResults.length)
        console.log("TV results:", tvResults.length)

        setMovies(movieResults.slice(0, 5))
        setTVShows(tvResults.slice(0, 5))

        if (movieResults.length === 0 && tvResults.length === 0) {
          setError("No results found")
        }
      } catch (error) {
        console.error("Search error:", error)
        setError("Search failed. Please try again.")
      } finally {
        setIsLoading(false)
      }
    }

    const debounceTimer = setTimeout(searchContent, 300)
    return () => clearTimeout(debounceTimer)
  }, [query])

  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = "unset"
      setQuery("")
      setMovies([])
      setTVShows([])
      setError(null)
    }

    return () => {
      document.body.style.overflow = "unset"
    }
  }, [open])

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm">
      <div className="container mx-auto px-4 py-8 h-full overflow-y-auto">
        <div className="max-w-2xl mx-auto">
          {/* Search Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-white">Search</h2>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onOpenChange(false)}
              className="text-white hover:bg-white/10"
            >
              <X className="h-6 w-6" />
            </Button>
          </div>

          {/* Search Input */}
          <div className="relative mb-8">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <Input
              type="text"
              placeholder="Search for movies or TV shows..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-10 bg-gray-900 border-gray-700 focus:border-cyan-500 text-white text-lg py-6"
              autoFocus
            />
          </div>

          {/* Search Results */}
          {query.trim() && (
            <div className="space-y-6">
              {isLoading && (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-500 mx-auto"></div>
                  <p className="text-gray-400 mt-2">Searching...</p>
                </div>
              )}

              {error && !isLoading && (
                <div className="text-center py-8">
                  <p className="text-red-400">{error}</p>
                  <p className="text-gray-500 text-sm mt-2">Try different keywords or check your spelling</p>
                </div>
              )}

              {!isLoading && !error && movies.length === 0 && tvShows.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-gray-400">No results found for "{query}"</p>
                  <p className="text-gray-500 text-sm mt-2">Try different keywords or check your spelling</p>
                </div>
              )}

              {movies.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold text-white mb-4">Movies ({movies.length})</h3>
                  <div className="space-y-3">
                    {movies.map((movie) => (
                      <Link
                        key={movie.id}
                        href={`/movie/${movie.id}`}
                        onClick={() => onOpenChange(false)}
                        className="flex items-center space-x-4 p-3 rounded-lg hover:bg-gray-800 transition-colors"
                      >
                        <div className="w-16 h-24 relative flex-shrink-0">
                          <Image
                            src={
                              movie.poster_path
                                ? `https://image.tmdb.org/t/p/w200${movie.poster_path}`
                                : "/placeholder.svg?height=144&width=96"
                            }
                            alt={movie.title}
                            fill
                            className="object-cover rounded"
                          />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-white">{movie.title}</h4>
                          <p className="text-sm text-gray-400">
                            {movie.release_date ? new Date(movie.release_date).getFullYear() : "Unknown"} • Movie
                          </p>
                          <p className="text-sm text-gray-500 line-clamp-2 mt-1">{movie.overview}</p>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {tvShows.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold text-white mb-4">TV Shows ({tvShows.length})</h3>
                  <div className="space-y-3">
                    {tvShows.map((show) => (
                      <Link
                        key={show.id}
                        href={`/tv/${show.id}`}
                        onClick={() => onOpenChange(false)}
                        className="flex items-center space-x-4 p-3 rounded-lg hover:bg-gray-800 transition-colors"
                      >
                        <div className="w-16 h-24 relative flex-shrink-0">
                          <Image
                            src={
                              show.poster_path
                                ? `https://image.tmdb.org/t/p/w200${show.poster_path}`
                                : "/placeholder.svg?height=144&width=96"
                            }
                            alt={show.name}
                            fill
                            className="object-cover rounded"
                          />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-white">{show.name}</h4>
                          <p className="text-sm text-gray-400">
                            {show.first_air_date ? new Date(show.first_air_date).getFullYear() : "Unknown"} • TV Show
                          </p>
                          <p className="text-sm text-gray-500 line-clamp-2 mt-1">{show.overview}</p>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
        <EnhancedSearch onClose={() => onOpenChange(false)} isDialog={true} />
      </div>
    </div>
  )
}
