"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Search, User } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { SearchDialog } from "@/components/search-dialog"
import { useState } from "react"

export default function Header() {
  const pathname = usePathname()
  const [showSearch, setShowSearch] = useState(false)

  const navItems = [
    { href: "/trending", label: "Trending" },
    { href: "/top-imdb", label: "Top IMDb" },
    { href: "/movies", label: "Movies" },
    { href: "/tv", label: "TV Shows" },
  ]

  return (
    <>
      <header className="fixed top-0 z-50 w-full bg-black/80 backdrop-blur-md border-b border-gray-800/50">
        <div className="container mx-auto px-4">
          <div className="flex h-16 items-center justify-between">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-2">
              <div className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                MOVIESTREAM
              </div>
            </Link>

            {/* Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "text-sm font-medium transition-colors hover:text-cyan-400",
                    pathname === item.href ? "text-cyan-400" : "text-gray-300",
                  )}
                >
                  {item.label}
                </Link>
              ))}
            </nav>

            {/* Right side actions */}
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowSearch(true)}
                className="text-gray-300 hover:text-white hover:bg-white/10"
              >
                <Search className="h-5 w-5" />
              </Button>

              <Button variant="ghost" className="text-gray-300 hover:text-white hover:bg-white/10">
                <User className="h-4 w-4 mr-2" />
                Sign in
              </Button>

              <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-medium">
                Sign up →
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile navigation */}
        <div className="md:hidden border-t border-gray-800/50">
          <div className="container mx-auto px-4 py-2">
            <div className="flex justify-around">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "text-xs font-medium py-2 px-3 rounded transition-colors",
                    pathname === item.href ? "text-cyan-400 bg-cyan-400/10" : "text-gray-400 hover:text-white",
                  )}
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </header>

      <SearchDialog open={showSearch} onOpenChange={setShowSearch} />
    </>
  )
}
