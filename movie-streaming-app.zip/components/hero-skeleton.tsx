export function HeroSkeleton() {
  return (
    <div className="relative h-[70vh] bg-gray-900 animate-pulse">
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent" />
      <div className="relative z-10 h-full flex items-center">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl">
            <div className="h-12 bg-gray-800 rounded w-3/4 mb-4"></div>
            <div className="flex items-center space-x-4 mb-4">
              <div className="h-6 w-16 bg-gray-800 rounded"></div>
              <div className="h-6 w-20 bg-gray-800 rounded"></div>
              <div className="h-6 w-16 bg-gray-800 rounded"></div>
            </div>
            <div className="space-y-2 mb-8">
              <div className="h-4 bg-gray-800 rounded w-full"></div>
              <div className="h-4 bg-gray-800 rounded w-5/6"></div>
              <div className="h-4 bg-gray-800 rounded w-4/6"></div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="h-12 w-32 bg-gray-800 rounded"></div>
              <div className="h-12 w-28 bg-gray-800 rounded"></div>
              <div className="h-12 w-28 bg-gray-800 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
