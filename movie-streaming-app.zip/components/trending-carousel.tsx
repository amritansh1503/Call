"use client"

import { useState, useRef } from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight, Play, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { VideoPlayer } from "@/components/video-player"
import type { Movie } from "@/lib/types"
import type { TVShow } from "@/lib/types"

// Update the interface to accept 'content' instead of 'movies'
interface TrendingCarouselProps {
  content: (Movie | TVShow)[]
}

// Update the function parameter to use 'content' instead of 'movies'
export function TrendingCarousel({ content }: TrendingCarouselProps) {
  const [showPlayer, setShowPlayer] = useState(false)
  const [selectedItem, setSelectedItem] = useState<Movie | TVShow | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const scrollAmount = 320
      scrollRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      })
    }
  }

  const handleWatchItem = (item: Movie | TVShow) => {
    setSelectedItem(item)
    setShowPlayer(true)
  }

  return (
    <>
      <div className="relative group">
        <Button
          variant="ghost"
          size="icon"
          className="absolute left-2 top-1/2 -translate-y-1/2 z-10 bg-black/50 hover:bg-black/70 text-white opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={() => scroll("left")}
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>

        <div
          ref={scrollRef}
          className="flex space-x-4 overflow-x-auto scrollbar-hide pb-4"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          {content.map((item, index) => (
            <div
              key={item.id}
              className="relative flex-shrink-0 w-64 h-96 rounded-lg overflow-hidden bg-gray-900 border border-gray-800 hover:border-purple-500 transition-all duration-300 hover:scale-105 group/card"
            >
              <Image
                src={
                  item.poster_path
                    ? `https://image.tmdb.org/t/p/w500${item.poster_path}`
                    : "/placeholder.svg?height=576&width=384"
                }
                alt={"title" in item ? item.title : item.name}
                fill
                className="object-cover"
                sizes="256px"
              />

              {/* Trending Badge */}
              <div className="absolute top-3 left-3 bg-gradient-to-r from-orange-500 to-red-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                #{index + 1}
              </div>

              {/* Rating */}
              {item.vote_average > 0 && (
                <div className="absolute top-3 right-3 bg-black/70 rounded-full p-2 flex items-center">
                  <Star className="h-3 w-3 text-yellow-400 mr-1" fill="currentColor" />
                  <span className="text-xs font-medium text-white">{item.vote_average.toFixed(1)}</span>
                </div>
              )}

              {/* Hover Overlay */}
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover/card:opacity-100 transition-opacity flex items-center justify-center">
                <Button
                  onClick={() => handleWatchItem(item)}
                  className="bg-white text-black hover:bg-gray-200 font-semibold"
                >
                  <Play className="h-4 w-4 mr-2" fill="currentColor" />
                  Watch Now
                </Button>
              </div>

              {/* Content Info */}
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black to-transparent">
                <h3 className="font-semibold text-white text-sm line-clamp-2 mb-1">
                  {"title" in item ? item.title : item.name}
                </h3>
                <p className="text-xs text-gray-300">
                  {"release_date" in item && item.release_date
                    ? new Date(item.release_date).getFullYear()
                    : "first_air_date" in item && item.first_air_date
                      ? new Date(item.first_air_date).getFullYear()
                      : "Unknown"}
                </p>
              </div>
            </div>
          ))}
        </div>

        <Button
          variant="ghost"
          size="icon"
          className="absolute right-2 top-1/2 -translate-y-1/2 z-10 bg-black/50 hover:bg-black/70 text-white opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={() => scroll("right")}
        >
          <ChevronRight className="h-6 w-6" />
        </Button>
      </div>

      {showPlayer && selectedItem && (
        <VideoPlayer
          title={"title" in selectedItem ? selectedItem.title : selectedItem.name}
          embedUrl={
            "title" in selectedItem
              ? `https://vidsrc.me/embed/movie?tmdb=${selectedItem.id}`
              : `https://vidsrc.me/embed/tv?tmdb=${selectedItem.id}`
          }
          onClose={() => setShowPlayer(false)}
          movieId={"title" in selectedItem ? selectedItem.id : undefined}
          showId={"name" in selectedItem ? selectedItem.id : undefined}
        />
      )}
    </>
  )
}
