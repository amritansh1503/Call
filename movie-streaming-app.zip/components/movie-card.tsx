"use client"

import type React from "react"

import Image from "next/image"
import Link from "next/link"
import { Star } from "lucide-react"
import type { Movie } from "@/lib/types"
import { VideoPlayer } from "@/components/video-player"
import { useState } from "react"

export default function MovieCard({ movie }: { movie: Movie }) {
  const [showPlayer, setShowPlayer] = useState(false)

  const handleWatchClick = (e: React.MouseEvent) => {
    e.preventDefault()
    setShowPlayer(true)
  }

  return (
    <>
      <Link href={`/movie/${movie.id}`}>
        <div className="movie-card rounded-lg overflow-hidden bg-gray-900 border border-gray-800 hover:border-purple-500 relative">
          <div className="relative movie-poster">
            <Image
              src={
                movie.poster_path
                  ? `https://image.tmdb.org/t/p/w500${movie.poster_path}`
                  : "/placeholder.svg?height=450&width=300"
              }
              alt={movie.title}
              fill
              className="object-cover"
              sizes="(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 20vw"
            />
            {movie.vote_average > 0 && (
              <div className="absolute top-2 right-2 bg-black/70 rounded-full p-1 flex items-center">
                <Star className="h-3 w-3 text-yellow-400 mr-1" fill="currentColor" />
                <span className="text-xs font-medium">{movie.vote_average.toFixed(1)}</span>
              </div>
            )}
          </div>
          <div className="absolute inset-0 bg-black/60 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
            <button
              onClick={handleWatchClick}
              className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg font-medium"
            >
              Watch Now
            </button>
          </div>
          <div className="p-3">
            <h3 className="font-medium text-sm line-clamp-1">{movie.title}</h3>
            <p className="text-xs text-gray-400 mt-1">{movie.release_date?.split("-")[0] || "Unknown"}</p>
          </div>
        </div>
      </Link>
      {showPlayer && (
        <VideoPlayer
          title={movie.title}
          embedUrl={`https://vidsrc.me/embed/movie?tmdb=${movie.id}`}
          onClose={() => setShowPlayer(false)}
        />
      )}
    </>
  )
}
